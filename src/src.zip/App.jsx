import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { OperationsManagerLayout } from './layouts/OperationsManagerLayout';
import { ClientHRLayout } from './layouts/ClientHRLayout';
import { ExecutiveLayout } from './layouts/ExecutiveLayout';
import { EmployeeForms } from './pages/EmployeeForms';
import { ClientAccounts } from './pages/ClientAccounts';
import { ClientDetails } from './pages/ClientDetails';
import { VerificationTracking } from './pages/VerificationTracking';
import { ExecutiveMonitoring } from './pages/ExecutiveMonitoring';
import { ExecutiveDetails } from './pages/ExecutiveDetails';
import { Reports } from './pages/Reports';
import { Dashboard as HRDashboard } from './pages/hr/Dashboard';
import { EmployeeList as HREmployeeList } from './pages/hr/EmployeeList';
import { CreateEmployee as HRCreateEmployee } from './pages/hr/CreateEmployee';
import { EmployeeDetails as HREmployeeDetails } from './pages/hr/EmployeeDetails';
import { VerificationTracking as HRTracking } from './pages/hr/VerificationTracking';
import { Reports as HRReports } from './pages/hr/Reports';
import { Notifications as HRNotifications } from './pages/hr/Notifications';
import { Dashboard as ExecDashboard } from './pages/exec/Dashboard';
import { AvailableTasks as ExecAvailableTasks } from './pages/exec/AvailableTasks';
import { MyTasks as ExecMyTasks } from './pages/exec/MyTasks';
import { VerificationWorkspace as ExecWorkspace } from './pages/exec/VerificationWorkspace';
import { CallLogs as ExecCallLogs } from './pages/exec/CallLogs';
import { VerificationTimeline as ExecTimeline } from './pages/exec/VerificationTimeline';
import { CompletedCases as ExecCompleted } from './pages/exec/CompletedCases';
import { AccountantLayout } from './layouts/AccountantLayout';
import { AccountantDashboard } from './pages/accountant/Dashboard';
import { Invoices as AccInvoicesPage } from './pages/accountant/Invoices';
import { CreateClient } from './pages/CreateClient';
import { mockDb } from './utils/mockDb';
import { ShieldCheck, UserCheck, ShieldAlert, LogIn, ArrowRight, BadgeIndianRupee, Eye, EyeOff } from 'lucide-react';

// Initialize Mock Database
mockDb.init();

// Login Screen Component
const Login = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    const session = mockDb.login(username, password);
    if (session) {
      if (session.role === 'admin') navigate('/admin/dashboard');
      else if (session.role === 'ops') navigate('/ops/dashboard');
      else if (session.role === 'hr') navigate('/hr/dashboard');
      else if (session.role === 'exec') navigate('/exec/dashboard');
      else if (session.role === 'accountant') navigate('/accountant/dashboard');
      else navigate('/');
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
      fontFamily: 'var(--font-family)',
      padding: '24px'
    }}>
      <div style={{ width: '100%', maxWidth: '400px', backgroundColor: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)' }}>
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
            <ShieldCheck size={40} color="#3b82f6" />
            <span style={{ fontSize: '28px', fontWeight: 800, letterSpacing: '1px', color: '#1e293b' }}>KPC</span>
          </div>
          <h1 style={{ fontSize: '20px', fontWeight: 600, color: '#475569' }}>Sign in to your account</h1>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {error && <div style={{ padding: '12px', backgroundColor: '#fee2e2', color: '#ef4444', borderRadius: '8px', fontSize: '14px', textAlign: 'center', fontWeight: 500 }}>{error}</div>}
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label style={{ fontSize: '13px', fontWeight: 600, color: '#475569' }}>Username</label>
            <input 
              type="text" 
              value={username} 
              onChange={e => setUsername(e.target.value)} 
              placeholder="Enter username" 
              style={{ padding: '12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px', outline: 'none' }}
              required 
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <label style={{ fontSize: '13px', fontWeight: 600, color: '#475569' }}>Password</label>
            <div style={{ position: 'relative' }}>
              <input 
                type={showPassword ? "text" : "password"} 
                value={password} 
                onChange={e => setPassword(e.target.value)} 
                placeholder="Enter password" 
                style={{ width: '100%', boxSizing: 'border-box', padding: '12px', paddingRight: '40px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px', outline: 'none' }}
                required 
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button type="submit" style={{ marginTop: '8px', padding: '14px', backgroundColor: '#3b82f6', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '15px', fontWeight: 600, cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
            <LogIn size={18} /> Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

// Placeholder components for HR screens that will be built in order
const HREmployees = () => (
  <div className="card" style={{ padding: '32px', textAlign: 'center' }}>
    <h2>Employee List (Screen 2)</h2>
    <p style={{ color: 'var(--text-gray)', marginTop: '8px' }}>This module is currently being prepared. Click 'Dashboard' to review progress.</p>
  </div>
);








const OpsDashboard = () => (
  <div className="card" style={{ padding: '32px' }}>
    <h1>Operations Dashboard</h1>
    <p style={{ color: 'var(--text-gray)', marginTop: '8px' }}>Welcome to the Operations Manager Dashboard. This module is frozen.</p>
  </div>
);







const AccDashboard = () => <div className="card" style={{ padding: '32px' }}><h2>Accountant Dashboard Placeholder</h2></div>;

const AccPayments = () => <div className="card" style={{ padding: '32px' }}><h2>Payments</h2></div>;
const AccBilling = () => <div className="card" style={{ padding: '32px' }}><h2>Client Billing</h2></div>;
const AccReports = () => <div className="card" style={{ padding: '32px' }}><h2>Revenue Reports</h2></div>;

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo });
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', background: '#fee2e2', color: '#991b1b', fontFamily: 'monospace' }}>
          <h2>Something went wrong.</h2>
          <details style={{ whiteSpace: 'pre-wrap' }}>
            {this.state.error && this.state.error.toString()}
            <br />
            {this.state.errorInfo && this.state.errorInfo.componentStack}
          </details>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Login />} />
          
          {/* Operations Manager Routes */}
          <Route path="/ops" element={<OperationsManagerLayout />}>
            <Route path="dashboard" element={<OpsDashboard />} />
            <Route path="forms" element={<EmployeeForms />} />
            <Route path="clients" element={<ClientAccounts />} />
            <Route path="clients/create" element={<CreateClient />} />
            <Route path="clients/:id/edit" element={<CreateClient />} />
            <Route path="clients/:id" element={<ClientDetails />} />
            <Route path="tracking" element={<VerificationTracking />} />
            <Route path="monitoring" element={<ExecutiveMonitoring />} />
            <Route path="monitoring/:id" element={<ExecutiveDetails />} />
            <Route path="reports" element={<Reports />} />
          </Route>

          {/* Client HR Routes */}
          <Route path="/hr" element={<ClientHRLayout />}>
            <Route path="dashboard" element={<HRDashboard />} />
            <Route path="employees" element={<HREmployeeList />} />
            <Route path="employees/create" element={<HRCreateEmployee />} />
            <Route path="employees/:id/edit" element={<HRCreateEmployee />} />
            <Route path="employees/:id" element={<HREmployeeDetails />} />
            <Route path="tracking" element={<HRTracking />} />
            <Route path="notifications" element={<HRNotifications />} />
            <Route path="reports" element={<HRReports />} />
          </Route>

          {/* Verification Executive Module */}
          <Route path="/exec" element={<ExecutiveLayout />}>
            <Route path="dashboard" element={<ExecDashboard />} />
            <Route path="tasks/available" element={<ExecAvailableTasks />} />
            <Route path="tasks/mine" element={<ExecMyTasks />} />
            <Route path="workspace/:id" element={<ExecWorkspace />} />
            <Route path="calls" element={<ExecCallLogs />} />
            <Route path="timeline" element={<ExecTimeline />} />
            <Route path="cases/completed" element={<ExecCompleted />} />
          </Route>

          <Route path="/accountant" element={<AccountantLayout />}>
            <Route path="dashboard" element={<AccountantDashboard />} />
            <Route path="invoices" element={<AccInvoicesPage />} />
            <Route path="payments" element={<AccPayments />} />
            <Route path="billing" element={<AccBilling />} />
            <Route path="reports" element={<AccReports />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;
