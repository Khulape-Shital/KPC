import React from 'react';
import { DashboardLayout } from './DashboardLayout';
import { 
  LayoutDashboard, Users, ShieldCheck, Bell, FileBarChart
} from 'lucide-react';

export const ClientHRLayout = () => {
  const navItems = [
    { label: 'Dashboard', path: '/hr/dashboard', icon: LayoutDashboard },
    { label: 'Employee List', path: '/hr/employees', icon: Users },
    { label: 'Verification Tracking', path: '/hr/tracking', icon: ShieldCheck },
    { label: 'Notifications', path: '/hr/notifications', icon: Bell },
    { label: 'Reports', path: '/hr/reports', icon: FileBarChart },
  ];

  return (
    <DashboardLayout 
      navigationItems={navItems}
      userName="Client HR"
      roleName="Acme Corp HR"
    />
  );
};
