import React from 'react';
import { DashboardLayout } from './DashboardLayout';
import { 
  LayoutDashboard, Inbox, List, PhoneCall, 
  Clock, CheckSquare
} from 'lucide-react';

export const ExecutiveLayout = () => {
  const navItems = [
    { label: 'Dashboard', path: '/exec/dashboard', icon: LayoutDashboard },
    { label: 'Available Tasks', path: '/exec/tasks/available', icon: Inbox },
    { label: 'My Tasks', path: '/exec/tasks/mine', icon: List },
    { label: 'Call Logs', path: '/exec/calls', icon: PhoneCall },
    { label: 'Verification Timeline', path: '/exec/timeline', icon: Clock },
    { label: 'Completed Cases', path: '/exec/completed', icon: CheckSquare },
  ];

  return (
    <DashboardLayout 
      navigationItems={navItems}
      userName="Amitabh S."
      roleName="Verification Executive"
    />
  );
};
