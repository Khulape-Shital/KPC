import React from 'react';
import { Users, PhoneCall, Clock, CheckCircle, AlertTriangle, Activity, Search, AlertCircle, PhoneMissed, PhoneForwarded } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const EXECUTIVES = [
  { id: 'EX-01', name: 'Amitabh S.', status: 'Online', cases: 28, completed: 8, pendingCalls: 3, avgTime: '2.4 Days', sla: '98%', rejected: 1, rank: 1, alert: 'Overloaded', trained: ['Identity', 'Education'] },
  { id: 'EX-02', name: 'Sanjay V.', status: 'Busy', cases: 22, completed: 4, pendingCalls: 12, avgTime: '4.1 Days', sla: '82%', rejected: 0, rank: 4, alert: 'SLA Risk', trained: ['Criminal', 'Background'] },
  { id: 'EX-03', name: 'Neha Gupta', status: 'Offline', cases: 5, completed: 12, pendingCalls: 0, avgTime: '1.8 Days', sla: '100%', rejected: 2, rank: 2, alert: 'Underutilized', trained: ['Identity', 'Address', 'Background'] },
  { id: 'EX-04', name: 'Ravi Kumar', status: 'On Call', cases: 18, completed: 5, pendingCalls: 8, avgTime: '3.5 Days', sla: '88%', rejected: 0, rank: 3, alert: null, trained: ['Police', 'Address'] }
];

export const ExecutiveMonitoring = () => {
  const navigate = useNavigate();

  const totalActive = EXECUTIVES.reduce((sum, e) => sum + e.cases, 0);
  const totalCompleted = EXECUTIVES.reduce((sum, e) => sum + e.completed, 0);
  const avgSla = (EXECUTIVES.reduce((sum, e) => sum + parseInt(e.sla), 0) / EXECUTIVES.length).toFixed(0);

  // Global Call Metrics Mock
  const callMetrics = { total: 420, connected: 315, missed: 45, avgDuration: '4m 12s', otpSuccess: '88%' };

  const getStatusColor = (status) => {
    switch(status) {
      case 'Online': return '#166534';
      case 'Busy': return '#ea580c';
      case 'Offline': return '#64748b';
      case 'On Call': return '#0284c7';
      default: return '#000';
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>Executive Monitoring</h1>
          <p style={{ color: 'var(--text-gray)' }}>Monitor workforce performance, distribute workload, and track SLA compliance.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Activity size={16} /> Workload Balancing Tool</button>
          <button className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>Bulk Reassignment</button>
        </div>
      </div>

      {/* Global Call Performance Dashboard */}
      <div className="card" style={{ padding: '16px', backgroundColor: 'var(--bg-surface)' }}>
        <h2 style={{ fontSize: '14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}><PhoneCall size={16} color="var(--primary-blue)" /> Global Call Performance Dashboard</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '16px' }}>
          <div><span style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600 }}>TOTAL CALLS</span><div style={{ fontSize: '20px', fontWeight: 700 }}>{callMetrics.total}</div></div>
          <div><span style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600 }}>CONNECTED</span><div style={{ fontSize: '20px', fontWeight: 700, color: '#166534' }}>{callMetrics.connected}</div></div>
          <div><span style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600 }}>MISSED</span><div style={{ fontSize: '20px', fontWeight: 700, color: '#dc2626' }}>{callMetrics.missed}</div></div>
          <div><span style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600 }}>AVG DURATION</span><div style={{ fontSize: '20px', fontWeight: 700 }}>{callMetrics.avgDuration}</div></div>
          <div><span style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600 }}>OTP SUCCESS RATE</span><div style={{ fontSize: '20px', fontWeight: 700, color: '#166534' }}>{callMetrics.otpSuccess}</div></div>
        </div>
      </div>

      {/* Aggregate Metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
        <div className="card" style={{ padding: '16px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>TOTAL ACTIVE CASES</div>
          <div style={{ fontSize: '24px', fontWeight: 700 }}>{totalActive}</div>
        </div>
        <div className="card" style={{ padding: '16px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>COMPLETED TODAY</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#166534' }}>{totalCompleted}</div>
        </div>
        <div className="card" style={{ padding: '16px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>TEAM SLA COMPLIANCE</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: avgSla > 90 ? '#166534' : '#ea580c' }}>{avgSla}%</div>
        </div>
        <div className="card" style={{ padding: '16px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>EXECUTIVES ONLINE</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#0284c7' }}>{EXECUTIVES.filter(e => e.status !== 'Offline').length}</div>
        </div>
      </div>

      <div className="card" style={{ padding: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div className="header-search" style={{ width: '300px', border: '1px solid var(--border-color)', margin: 0, backgroundColor: '#fff' }}>
          <Search size={16} color="var(--text-gray)" />
          <input type="text" placeholder="Search Executive Name" />
        </div>
        <select style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <option>All Statuses</option>
          <option>Online</option>
          <option>Busy</option>
          <option>On Call</option>
        </select>
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)' }}>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>EXECUTIVE</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>STATUS</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>WORKLOAD ALERT</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>ACTIVE CASES</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>COMPLETED</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>AVG TIME</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>SLA %</th>
              <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', textAlign: 'right' }}>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {EXECUTIVES.map(exec => (
              <tr key={exec.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                <td style={{ padding: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div className="avatar" style={{ backgroundColor: 'var(--bg-surface)' }}>{exec.name.substring(0, 2).toUpperCase()}</div>
                    <div>
                      <div style={{ fontWeight: 600 }}>{exec.name}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>ID: {exec.id} • Rank #{exec.rank}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', fontWeight: 600, color: getStatusColor(exec.status) }}>
                    <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: getStatusColor(exec.status) }} />
                    {exec.status}
                  </div>
                </td>
                <td style={{ padding: '16px' }}>
                  {exec.alert && (
                    <span style={{ fontSize: '11px', padding: '4px 8px', borderRadius: '4px', backgroundColor: exec.alert === 'Overloaded' || exec.alert === 'SLA Risk' ? '#fef2f2' : '#f0fdf4', color: exec.alert === 'Overloaded' || exec.alert === 'SLA Risk' ? '#dc2626' : '#166534', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      <AlertTriangle size={12} /> {exec.alert}
                    </span>
                  )}
                </td>
                <td style={{ padding: '16px', fontWeight: 600 }}>{exec.cases}</td>
                <td style={{ padding: '16px', fontWeight: 500 }}>{exec.completed}</td>
                <td style={{ padding: '16px' }}>{exec.avgTime}</td>
                <td style={{ padding: '16px', fontWeight: 600, color: parseInt(exec.sla) < 90 ? '#ea580c' : '#166534' }}>{exec.sla}</td>
                <td style={{ padding: '16px', textAlign: 'right' }}>
                  <button className="btn btn-outline" onClick={() => navigate(`/ops/monitoring/${exec.id}`)} style={{ padding: '4px 8px', fontSize: '12px' }}>View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </div>
  );
};
