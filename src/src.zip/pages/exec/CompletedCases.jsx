import React, { useState, useEffect, useMemo } from 'react';
import { 
  CheckCircle2, Search, Filter, Clock, Download, 
  Eye, History, TrendingUp, BarChart3, AlertTriangle, X, Target
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';
import { useNavigate } from 'react-router-dom';

export const CompletedCases = () => {
  const [completedCases, setCompletedCases] = useState([]);
  const navigate = useNavigate();
  
  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [serviceFilter, setServiceFilter] = useState('All');
  const [slaFilter, setSlaFilter] = useState('All');
  
  // Drawer
  const [selectedCase, setSelectedCase] = useState(null);
  const [drawerTab, setDrawerTab] = useState('details'); // 'details' | 'timeline'

  const EXEC_NAME = 'Amitabh S.';

  const fetchCompletedCases = () => {
    mockDb.init();
    const employees = mockDb.getEmployees();
    
    const cases = employees.filter(emp => {
      // Must be completed or approved/rejected
      const isCompleted = ['completed', 'approved', 'rejected'].includes(emp.status.toLowerCase());
      // Must be assigned to this exec
      const assignmentEvent = emp.timeline?.find(t => t.event === 'Executive Assigned');
      const isMine = assignmentEvent && assignmentEvent.details === EXEC_NAME;
      
      return isCompleted && isMine;
    }).map(emp => {
      // Find completion date
      const completionEvent = emp.timeline?.find(t => t.event === 'Verification Completed' || t.event.includes('Approved') || t.event.includes('Rejected'));
      const completionDate = completionEvent ? completionEvent.date : new Date().toISOString();
      const submissionDate = emp.timeline?.find(t => t.event === 'Submitted')?.date || new Date().toISOString();
      
      // Rough calc for processing time
      const diffMs = new Date(completionDate) - new Date(submissionDate);
      const diffDays = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
      
      let slaStatus = 'Within SLA';
      if (diffDays > 7) slaStatus = 'SLA Breached';
      else if (diffDays > 4) slaStatus = 'Near SLA';

      return {
        ...emp,
        completionDate,
        submissionDate,
        processingTime: `${diffDays} Days`,
        calculatedSla: slaStatus
      };
    });

    cases.sort((a, b) => new Date(b.completionDate) - new Date(a.completionDate));
    setCompletedCases(cases);
  };

  useEffect(() => {
    fetchCompletedCases();
  }, []);

  const filteredCases = useMemo(() => {
    return completedCases.filter(c => {
      const matchSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          c.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchService = serviceFilter === 'All' || (c.services && c.services[0] === serviceFilter);
      const matchSla = slaFilter === 'All' || c.calculatedSla === slaFilter;
      
      return matchSearch && matchService && matchSla;
    });
  }, [completedCases, searchTerm, serviceFilter, slaFilter]);

  // Metrics
  const totalCompleted = completedCases.length;
  const today = new Date().toISOString().split('T')[0];
  const completedToday = completedCases.filter(c => c.completionDate.startsWith(today)).length;
  // Mock 'this week' and 'this month' based on today's date logic or just static numbers for UI if limited data
  const completedThisWeek = completedToday + 14; 
  const completedThisMonth = completedThisWeek + 45;
  const slaSuccess = totalCompleted > 0 ? Math.round((completedCases.filter(c => c.calculatedSla === 'Within SLA').length / totalCompleted) * 100) : 0;

  const getStatusBadge = (status) => {
    switch(status.toLowerCase()) {
      case 'completed': return { color: '#10b981', bg: '#ecfdf5' };
      case 'approved': return { color: '#10b981', bg: '#ecfdf5' };
      case 'rejected': return { color: '#ef4444', bg: '#fef2f2' };
      default: return { color: '#64748b', bg: '#f1f5f9' };
    }
  };

  const getSlaBadge = (sla) => {
    switch(sla) {
      case 'Within SLA': return { color: '#10b981', bg: '#ecfdf5' };
      case 'Near SLA': return { color: '#f59e0b', bg: '#fef3c7' };
      case 'SLA Breached': return { color: '#ef4444', bg: '#fef2f2' };
      default: return { color: '#64748b', bg: '#f1f5f9' };
    }
  };

  return (
    <div className="page-container" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '24px', animation: 'fadeIn 0.5s ease-out' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <CheckCircle2 size={26} color="#10b981" />
            Completed Cases
          </h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '6px', fontSize: '14px' }}>
            Historical archive of successfully completed verification cases and productivity metrics.
          </p>
        </div>
      </div>

      {/* TOP KPI CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '16px' }}>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #3b82f6' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>Total Completed</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '8px' }}>{totalCompleted}</div>
        </div>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #10b981' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>Completed Today</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#10b981', marginTop: '8px' }}>{completedToday}</div>
        </div>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #0ea5e9' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>This Week</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#0ea5e9', marginTop: '8px' }}>{completedThisWeek}</div>
        </div>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #8b5cf6' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>This Month</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#8b5cf6', marginTop: '8px' }}>{completedThisMonth}</div>
        </div>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #64748b' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>Avg Completion Time</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '8px' }}>2.4 Days</div>
        </div>
        <div className="card metric-card" style={{ padding: '16px', backgroundColor: '#fff', borderLeft: '4px solid #10b981' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>SLA Success Rate</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#10b981', marginTop: '8px' }}>{slaSuccess}%</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', gap: '24px', alignItems: 'start' }}>
        
        {/* Main Content Area */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* FILTER BAR */}
          <div className="card" style={{ padding: '16px', backgroundColor: '#fff', display: 'flex', gap: '16px', flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, minWidth: '250px' }}>
              <Search size={18} color="var(--text-light)" />
              <input 
                type="text" 
                placeholder="Search Employee or ID..." 
                className="input-field"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                style={{ width: '100%', padding: '8px' }}
              />
            </div>
            
            <select className="select-input" value={serviceFilter} onChange={e => setServiceFilter(e.target.value)} style={{ padding: '8px', width: '180px' }}>
              <option value="All">All Services</option>
              <option value="Identity Verification">Identity Verification</option>
              <option value="Criminal Background">Criminal Background</option>
              <option value="Address Verification">Address Verification</option>
            </select>

            <select className="select-input" value={slaFilter} onChange={e => setSlaFilter(e.target.value)} style={{ padding: '8px', width: '150px' }}>
              <option value="All">All SLA Status</option>
              <option value="Within SLA">Within SLA</option>
              <option value="Near SLA">Near SLA</option>
              <option value="SLA Breached">SLA Breached</option>
            </select>

            <button className="btn btn-outline" onClick={() => { setSearchTerm(''); setServiceFilter('All'); setSlaFilter('All'); }} style={{ padding: '8px 16px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Filter size={14} /> Reset
            </button>
          </div>

          {/* CASES TABLE */}
          <div className="card" style={{ backgroundColor: '#fff', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table" style={{ width: '100%', minWidth: '900px', borderCollapse: 'collapse', textAlign: 'left' }}>
                <thead style={{ backgroundColor: '#f8fafc' }}>
                  <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>EMPLOYEE</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>COMPANY</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SERVICE</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>COMPLETED DATE</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>PROCESSING TIME</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SLA / STATUS</th>
                    <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textAlign: 'right' }}>ACTIONS</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCases.length === 0 ? (
                    <tr>
                      <td colSpan="7" style={{ padding: '64px 24px', textAlign: 'center' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
                          <div style={{ width: '64px', height: '64px', borderRadius: '50%', backgroundColor: 'var(--bg-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <CheckCircle2 size={32} color="var(--text-light)" />
                          </div>
                          <div>
                            <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)' }}>No completed cases found.</h3>
                            <p style={{ fontSize: '13px', color: 'var(--text-gray)', marginTop: '4px' }}>Cases you mark as complete in the Verification Workspace will appear here.</p>
                          </div>
                          <button className="btn btn-primary" onClick={() => navigate('/exec/tasks/mine')} style={{ marginTop: '8px' }}>Go To My Tasks</button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredCases.map(c => {
                      const statBadge = getStatusBadge(c.status);
                      const slaBadge = getSlaBadge(c.calculatedSla);
                      
                      return (
                        <tr key={c.id} className="table-row-hover" style={{ borderBottom: '1px solid var(--border-color)' }}>
                          <td style={{ padding: '16px' }}>
                            <div style={{ fontWeight: 600, fontSize: '13px', color: 'var(--text-dark)' }}>{c.name}</div>
                            <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{c.id}</div>
                          </td>
                          <td style={{ padding: '16px', fontSize: '13px', color: 'var(--text-dark)' }}>Acme Corp</td>
                          <td style={{ padding: '16px', fontSize: '13px', color: 'var(--text-dark)' }}>{c.services ? c.services[0] : 'Identity Verification'}</td>
                          <td style={{ padding: '16px' }}>
                            <div style={{ fontSize: '13px', color: 'var(--text-dark)' }}>{new Date(c.completionDate).toLocaleDateString()}</div>
                            <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{new Date(c.completionDate).toLocaleTimeString([], {timeStyle: 'short'})}</div>
                          </td>
                          <td style={{ padding: '16px', fontSize: '13px', color: 'var(--text-dark)' }}>
                            {c.processingTime}
                          </td>
                          <td style={{ padding: '16px' }}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-start' }}>
                              <span style={{ fontSize: '11px', fontWeight: 600, color: statBadge.color, backgroundColor: statBadge.bg, padding: '2px 6px', borderRadius: '4px', textTransform: 'capitalize' }}>
                                {c.status.replace('-', ' ')}
                              </span>
                              <span style={{ fontSize: '10px', fontWeight: 600, color: slaBadge.color, backgroundColor: slaBadge.bg, padding: '2px 6px', borderRadius: '4px' }}>
                                {c.calculatedSla}
                              </span>
                            </div>
                          </td>
                          <td style={{ padding: '16px', textAlign: 'right' }}>
                            <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                              <button className="btn btn-outline" onClick={() => setSelectedCase(c)} style={{ padding: '6px', fontSize: '12px' }} title="View Details">
                                <Eye size={14} />
                              </button>
                              <button className="btn btn-outline" onClick={() => navigate(`/exec/workspace/${c.id}`)} style={{ padding: '6px', fontSize: '12px' }} title="View Workspace">
                                <History size={14} />
                              </button>
                              <button className="btn btn-outline" style={{ padding: '6px', fontSize: '12px' }} title="Download Report">
                                <Download size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Side Widgets */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* ANALYTICS SECTION */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Target size={18} color="var(--primary-blue)" /> Performance Analytics
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)' }}>SLA Success %</span>
                  <span style={{ fontSize: '12px', fontWeight: 700, color: '#10b981' }}>{slaSuccess}%</span>
                </div>
                <div style={{ height: '6px', backgroundColor: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${slaSuccess}%`, backgroundColor: '#10b981' }}></div>
                </div>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', backgroundColor: '#f8fafc', borderRadius: '6px', border: '1px solid var(--border-color)' }}>
                <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)' }}>Completion Rate</span>
                <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--primary-blue)' }}>94%</span>
              </div>

              <div style={{ padding: '12px', backgroundColor: '#f8fafc', borderRadius: '6px', border: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '32px', height: '32px', borderRadius: '50%', backgroundColor: '#dbeafe', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <TrendingUp size={16} color="#3b82f6" />
                </div>
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Weekly Throughput</div>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>+18% vs last week</div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* COMPLETED CASE DETAILS DRAWER */}
      {selectedCase && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 100 }} onClick={() => setSelectedCase(null)}></div>
          <div style={{ position: 'fixed', top: 0, right: 0, bottom: 0, width: '500px', backgroundColor: '#fff', zIndex: 101, display: 'flex', flexDirection: 'column', boxShadow: '-4px 0 24px rgba(0,0,0,0.1)', animation: 'slideInRight 0.3s ease-out' }}>
            
            <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f8fafc' }}>
              <div>
                <h2 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  {selectedCase.name}
                </h2>
                <span style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{selectedCase.id} • Completed {new Date(selectedCase.completionDate).toLocaleDateString()}</span>
              </div>
              <button onClick={() => setSelectedCase(null)} style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-gray)' }}>
                <X size={20} />
              </button>
            </div>

            {/* Tabs */}
            <div style={{ display: 'flex', borderBottom: '1px solid var(--border-color)' }}>
              <button 
                onClick={() => setDrawerTab('details')}
                style={{ flex: 1, padding: '12px', background: 'transparent', border: 'none', borderBottom: drawerTab === 'details' ? '2px solid var(--primary-blue)' : '2px solid transparent', color: drawerTab === 'details' ? 'var(--primary-blue)' : 'var(--text-gray)', fontWeight: 600, fontSize: '13px', cursor: 'pointer' }}
              >
                Verification Details
              </button>
              <button 
                onClick={() => setDrawerTab('timeline')}
                style={{ flex: 1, padding: '12px', background: 'transparent', border: 'none', borderBottom: drawerTab === 'timeline' ? '2px solid var(--primary-blue)' : '2px solid transparent', color: drawerTab === 'timeline' ? 'var(--primary-blue)' : 'var(--text-gray)', fontWeight: 600, fontSize: '13px', cursor: 'pointer' }}
              >
                Full Timeline
              </button>
            </div>

            <div style={{ padding: '24px', overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
              
              {drawerTab === 'details' && (
                <>
                  {/* Candidate Summary */}
                  <div>
                    <h3 style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>Candidate Summary</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', backgroundColor: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                      <div>
                        <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Company</div>
                        <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>Acme Corp</div>
                      </div>
                      <div>
                        <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Service Type</div>
                        <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{selectedCase.services ? selectedCase.services[0] : 'Identity Verification'}</div>
                      </div>
                    </div>
                  </div>

                  {/* Verification Summary */}
                  <div>
                    <h3 style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>Verification Summary</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', border: '1px solid var(--border-color)', borderRadius: '8px', padding: '16px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px' }}><CheckCircle2 size={14} color="#10b981"/> Calls Completed</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>Yes</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px' }}><CheckCircle2 size={14} color="#10b981"/> OTP Verified</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>Yes</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px' }}><CheckCircle2 size={14} color="#10b981"/> Portals Checked</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>Yes</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px' }}><CheckCircle2 size={14} color="#10b981"/> Documents Reviewed</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>Yes</span>
                      </div>
                    </div>
                  </div>

                  {/* Completion Information */}
                  <div>
                    <h3 style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>Completion Information</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Completion Date</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{new Date(selectedCase.completionDate).toLocaleString()}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Processing Time</span>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{selectedCase.processingTime}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '4px', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
                        <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Verification Outcome</span>
                        <span style={{ fontSize: '12px', fontWeight: 600, color: getStatusBadge(selectedCase.status).color, backgroundColor: getStatusBadge(selectedCase.status).bg, padding: '4px 8px', borderRadius: '4px', textTransform: 'capitalize' }}>
                          {selectedCase.status.replace('-', ' ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Audit Requirements */}
                  <div>
                    <h3 style={{ fontSize: '12px', fontWeight: 700, color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px' }}>Audit Details</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11px', color: 'var(--text-gray)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Case ID:</span>
                        <span style={{ color: 'var(--text-dark)', fontWeight: 500, fontFamily: 'monospace' }}>{selectedCase.id}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Completion ID:</span>
                        <span style={{ color: 'var(--text-dark)', fontWeight: 500, fontFamily: 'monospace' }}>CMP-{selectedCase.id.slice(4)}</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Executive ID:</span>
                        <span style={{ color: 'var(--text-dark)', fontWeight: 500 }}>{EXEC_NAME}</span>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {drawerTab === 'timeline' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', position: 'relative' }}>
                  {selectedCase.timeline && selectedCase.timeline.slice().reverse().map((t, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: '12px', position: 'relative' }}>
                      {idx !== selectedCase.timeline.length - 1 && (
                        <div style={{ position: 'absolute', top: '16px', left: '7px', bottom: '-16px', width: '2px', backgroundColor: 'var(--border-color)' }}></div>
                      )}
                      <div style={{ width: '16px', height: '16px', borderRadius: '50%', backgroundColor: 'var(--bg-secondary)', border: '2px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1, marginTop: '2px' }}>
                        <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'var(--primary-blue)' }}></div>
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{t.event}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{new Date(t.date).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</div>
                        </div>
                        {t.details && (
                          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>{t.details}</div>
                        )}
                        <div style={{ fontSize: '10px', color: 'var(--text-light)', marginTop: '4px' }}>By: {t.user}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

            </div>

            {/* Actions */}
            <div style={{ padding: '20px 24px', borderTop: '1px solid var(--border-color)', backgroundColor: '#fff', display: 'flex', gap: '12px' }}>
              <button className="btn btn-primary" style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px' }}>
                <Download size={16} /> Download Verification Report
              </button>
            </div>
          </div>
        </>
      )}

    </div>
  );
};
