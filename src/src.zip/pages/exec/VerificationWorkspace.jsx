import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, User, Building2, Phone, Briefcase, 
  Clock, ShieldAlert, CheckCircle2, AlertTriangle, PlaySquare
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

import { DocumentReviewPanel } from './workspace/DocumentReviewPanel';
import { CallVerificationPanel } from './workspace/CallVerificationPanel';
import { OTPVerificationPanel } from './workspace/OTPVerificationPanel';
import { PortalVerificationPanel } from './workspace/PortalVerificationPanel';
import { AttachmentCenter } from './workspace/AttachmentCenter';
import { VerificationNotesPanel } from './workspace/VerificationNotesPanel';
import { CompletionChecklist } from './workspace/CompletionChecklist';
import { ActivityTimeline } from './workspace/ActivityTimeline';

export const VerificationWorkspace = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  
  // Checklist State tracking
  const [checklist, setChecklist] = useState({
    documentsReviewed: false, // In a real app, this would be computed by checking if all docs are previewed
    callCompleted: false,
    otpVerified: false,
    portalVerified: false,
    notesAdded: false
  });

  const [showConfirmModal, setShowConfirmModal] = useState(false);

  useEffect(() => {
    mockDb.init();
    const emp = mockDb.getEmployeeById(id);
    if (emp) {
      setEmployee(emp);
      
      // Auto-compute some checklist states from existing timeline
      const t = emp.timeline || [];
      setChecklist(prev => ({
        ...prev,
        callCompleted: t.some(evt => evt.event === 'Call Verified'),
        otpVerified: t.some(evt => evt.event === 'OTP Verified'),
        portalVerified: t.some(evt => evt.event === 'Portal Verified'),
        notesAdded: t.some(evt => evt.event === 'Notes Added'),
        documentsReviewed: true // mocked to true for now
      }));
    } else {
      navigate('/exec/tasks/mine'); // Redirect if invalid
    }
  }, [id, navigate]);

  if (!employee) return <div style={{ padding: '24px' }}>Loading workspace...</div>;

  const handleUpdate = (updatePayload) => {
    // In a real app, we use centralized Zustand/Redux. Here we update mockDb
    let updatedEmp = { ...employee };
    let currentTimeline = [...(updatedEmp.timeline || [])];
    
    switch (updatePayload.type) {
      case 'call-log':
        currentTimeline.push({
          event: `Call ${updatePayload.status}`,
          user: 'Amitabh S.',
          date: updatePayload.timestamp,
          details: updatePayload.remarks
        });
        if (updatePayload.status === 'Verified') {
          setChecklist(prev => ({ ...prev, callCompleted: true }));
        }
        break;
      case 'otp-sent':
        currentTimeline.push({
          event: 'OTP Sent',
          user: 'Amitabh S.',
          date: updatePayload.timestamp
        });
        break;
      case 'otp-verified':
        currentTimeline.push({
          event: 'OTP Verified',
          user: 'System',
          date: updatePayload.timestamp
        });
        setChecklist(prev => ({ ...prev, otpVerified: true }));
        break;
      case 'portal-update':
        const verifiedPortals = updatePayload.portals.filter(p => p.status === 'Verified');
        if (verifiedPortals.length > 0) {
          setChecklist(prev => ({ ...prev, portalVerified: true }));
          currentTimeline.push({
            event: 'Portal Verified',
            user: 'Amitabh S.',
            date: new Date().toISOString(),
            details: `Verified via ${verifiedPortals[0].name}`
          });
        }
        break;
      case 'add-note':
        currentTimeline.push({
          event: 'Notes Added',
          user: updatePayload.user,
          date: updatePayload.timestamp,
          category: updatePayload.category,
          details: updatePayload.content
        });
        setChecklist(prev => ({ ...prev, notesAdded: true }));
        break;
      default:
        break;
    }

    // Set employee to In Progress if it was assigned
    if (updatedEmp.status === 'assigned') {
      updatedEmp.status = 'in-progress';
    }

    updatedEmp.timeline = currentTimeline;
    mockDb.updateEmployee(updatedEmp.id, updatedEmp);
    setEmployee(updatedEmp);
  };

  const handleCompleteVerification = () => {
    // Validation
    const allChecked = Object.values(checklist).every(Boolean);
    if (!allChecked) {
      alert("Please complete all verification steps before submitting.");
      setShowConfirmModal(false);
      return;
    }

    // Finalize
    let currentTimeline = [...(employee.timeline || [])];
    currentTimeline.push({
      event: 'Verification Completed',
      user: 'Amitabh S.',
      date: new Date().toISOString(),
      details: 'All checks cleared and submitted.'
    });

    const updatedEmp = { ...employee, status: 'completed', timeline: currentTimeline };
    mockDb.updateEmployee(updatedEmp.id, updatedEmp);
    setEmployee(updatedEmp);
    
    setShowConfirmModal(false);
    
    // Redirect after short delay
    setTimeout(() => {
      navigate('/exec/tasks/mine');
    }, 1500);
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'Urgent': return '#ef4444';
      case 'High': return '#f97316';
      case 'Medium': return '#3b82f6';
      case 'Low': return '#64748b';
      default: return '#64748b';
    }
  };

  const isCompleted = employee.status === 'completed' || employee.status === 'approved' || employee.status === 'rejected';

  return (
    <div className="page-container" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '24px', animation: 'fadeIn 0.5s ease-out', position: 'relative' }}>
      
      {/* Header Area */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <button className="btn btn-outline" onClick={() => navigate(-1)} style={{ padding: '8px', display: 'flex', alignItems: 'center' }}>
          <ArrowLeft size={16} />
        </button>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <h1 style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text-dark)' }}>{employee.name}</h1>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#3b82f6', backgroundColor: '#eff6ff', padding: '4px 8px', borderRadius: '4px' }}>{employee.id}</span>
            <span style={{ fontSize: '12px', fontWeight: 600, color: getPriorityColor(employee.priority), backgroundColor: `${getPriorityColor(employee.priority)}15`, padding: '4px 8px', borderRadius: '4px' }}>
              {employee.priority} Priority
            </span>
          </div>
          <p style={{ fontSize: '13px', color: 'var(--text-gray)', marginTop: '4px' }}>
            Verification Workspace • Assigned {new Date(employee.timeline?.find(t => t.event === 'Executive Assigned')?.date || Date.now()).toLocaleDateString()}
          </p>
        </div>
      </div>

      {isCompleted && (
        <div style={{ padding: '16px', backgroundColor: '#ecfdf5', border: '1px solid #10b981', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '8px', color: '#065f46', fontWeight: 600 }}>
          <CheckCircle2 size={20} /> This verification is {employee.status}. The workspace is now read-only.
        </div>
      )}

      {/* Split Layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '7fr 4fr', gap: '24px', alignItems: 'start' }}>
        
        {/* LEFT COLUMN - Primary Workspace */}
        <div style={{ display: 'flex', flexDirection: 'column', pointerEvents: isCompleted ? 'none' : 'auto', opacity: isCompleted ? 0.7 : 1 }}>
          
          {/* SECTION 1 — Candidate Summary */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <User size={18} color="var(--primary-blue)" /> Candidate Information
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <Building2 size={16} color="var(--text-gray)" style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Company</div>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-dark)' }}>Acme Corp</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <Briefcase size={16} color="var(--text-gray)" style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Service Package</div>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-dark)' }}>{employee.services ? employee.services[0] : 'Identity Verification'}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <Phone size={16} color="var(--text-gray)" style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Contact Numbers</div>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-dark)' }}>{employee.contactNumber}</div>
                  {employee.alternateContactNumber && <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>Alt: {employee.alternateContactNumber}</div>}
                </div>
              </div>
              <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start' }}>
                <User size={16} color="var(--text-gray)" style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>Parents</div>
                  <div style={{ fontSize: '13px', color: 'var(--text-dark)' }}>Father: {employee.fatherName || 'N/A'}</div>
                  <div style={{ fontSize: '13px', color: 'var(--text-dark)' }}>Mother: {employee.motherName || 'N/A'}</div>
                </div>
              </div>
            </div>
          </div>

          <DocumentReviewPanel documents={employee.documents} />
          
          <CallVerificationPanel employee={employee} onUpdate={handleUpdate} />
          
          <OTPVerificationPanel employee={employee} onUpdate={handleUpdate} />
          
          <PortalVerificationPanel onUpdate={handleUpdate} />
          
          <AttachmentCenter employee={employee} />
          
          <VerificationNotesPanel employee={employee} onUpdate={handleUpdate} />

        </div>

        {/* RIGHT COLUMN - Context Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', position: 'sticky', top: '24px' }}>
          
          {/* SECTION 10 — SLA Panel */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Clock size={18} color="var(--primary-blue)" /> SLA & Status
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Current Status</span>
                <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{employee.status.replace('-', ' ').toUpperCase()}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>SLA Target</span>
                <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{employee.slaStatus || '7 Days'}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Days Active</span>
                <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>2 Days</span>
              </div>
            </div>
          </div>

          <CompletionChecklist employee={employee} checklistState={checklist} />
          
          {/* SECTION 11 — Escalation Center */}
          {!isCompleted && (
            <div className="card" style={{ padding: '20px', backgroundColor: '#fff', borderLeft: '4px solid #ef4444' }}>
              <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#ef4444', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <ShieldAlert size={16} /> Escalation Center
              </h3>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '12px' }}>
                If you are blocked, raise an escalation. This will alert Operations but keep the case assigned to you.
              </p>
              <button className="btn btn-outline" style={{ width: '100%', color: '#ef4444', borderColor: '#fca5a5', display: 'flex', justifyContent: 'center', gap: '8px' }}>
                <AlertTriangle size={14} /> Raise Escalation
              </button>
            </div>
          )}

          {/* Action Button */}
          {!isCompleted && (
            <button 
              className="btn btn-primary" 
              onClick={() => setShowConfirmModal(true)}
              disabled={!Object.values(checklist).every(Boolean)}
              style={{ padding: '16px', fontSize: '16px', fontWeight: 700, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px', opacity: Object.values(checklist).every(Boolean) ? 1 : 0.6 }}
            >
              <CheckCircle2 size={20} /> Mark Verification Complete
            </button>
          )}

          <ActivityTimeline timeline={employee.timeline} />

        </div>
      </div>

      {/* Completion Confirmation Modal */}
      {showConfirmModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className="card" style={{ width: '100%', maxWidth: '450px', backgroundColor: '#fff', padding: '32px', display: 'flex', flexDirection: 'column', gap: '20px', animation: 'fadeIn 0.2s ease-out' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: '#ecfdf5', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto' }}>
              <PlaySquare size={28} color="#10b981" />
            </div>
            <div style={{ textAlign: 'center' }}>
              <h2 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '8px' }}>Complete Verification?</h2>
              <p style={{ fontSize: '14px', color: 'var(--text-gray)', lineHeight: '1.5' }}>
                You are about to mark <strong>{employee.name}</strong> as completed. This action will finalize the report and lock the workspace. You will not be able to make further edits.
              </p>
            </div>
            <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
              <button className="btn btn-outline" onClick={() => setShowConfirmModal(false)} style={{ flex: 1 }}>Review Again</button>
              <button className="btn btn-primary" onClick={handleCompleteVerification} style={{ flex: 1, backgroundColor: '#10b981', display: 'flex', justifyContent: 'center', gap: '6px' }}>
                <CheckCircle2 size={16} /> Finalize & Submit
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
