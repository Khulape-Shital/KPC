import React from 'react';
import { CheckSquare, CheckCircle2, Circle, AlertTriangle } from 'lucide-react';

export const CompletionChecklist = ({ employee, checklistState }) => {
  
  // checklistState passed from parent which computes this based on the latest actions
  // e.g., { documentsReviewed: true, callCompleted: true, otpVerified: true, portalVerified: false, notesAdded: true }
  
  const items = [
    { id: 'documentsReviewed', label: 'Documents Reviewed', checked: checklistState?.documentsReviewed },
    { id: 'callCompleted', label: 'Call Verification Completed', checked: checklistState?.callCompleted },
    { id: 'otpVerified', label: 'OTP Verified', checked: checklistState?.otpVerified },
    { id: 'portalVerified', label: 'Portal Verification Completed', checked: checklistState?.portalVerified },
    { id: 'notesAdded', label: 'Notes Added', checked: checklistState?.notesAdded }
  ];

  const allChecked = items.every(i => i.checked);

  return (
    <div className="card" style={{ padding: '20px', backgroundColor: '#fff', marginBottom: '24px' }}>
      <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <CheckSquare size={18} color="var(--primary-blue)" /> Completion Checklist
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {items.map((item, idx) => (
          <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {item.checked ? (
              <CheckCircle2 size={16} color="#10b981" />
            ) : (
              <Circle size={16} color="#cbd5e1" />
            )}
            <span style={{ fontSize: '13px', color: item.checked ? 'var(--text-dark)' : 'var(--text-gray)', fontWeight: item.checked ? 600 : 400 }}>
              {item.label}
            </span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: '20px', padding: '12px', borderRadius: '6px', backgroundColor: allChecked ? '#ecfdf5' : '#fef2f2', border: `1px solid ${allChecked ? '#a7f3d0' : '#fca5a5'}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', fontWeight: 600, color: allChecked ? '#065f46' : '#991b1b' }}>
          {allChecked ? (
            <><CheckCircle2 size={14} /> Ready for Completion</>
          ) : (
            <><AlertTriangle size={14} /> Verification cannot be completed until all requirements are met.</>
          )}
        </div>
      </div>
    </div>
  );
};
