import React from 'react';
import { History } from 'lucide-react';

export const ActivityTimeline = ({ timeline }) => {
  return (
    <div className="card" style={{ padding: '20px', backgroundColor: '#fff', marginBottom: '24px' }}>
      <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <History size={18} color="var(--primary-blue)" /> Activity Timeline
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', position: 'relative' }}>
        {timeline && timeline.length > 0 ? (
          timeline.slice().reverse().map((t, idx) => (
            <div key={idx} style={{ display: 'flex', gap: '12px', position: 'relative' }}>
              {idx !== timeline.length - 1 && (
                <div style={{ position: 'absolute', top: '16px', left: '7px', bottom: '-16px', width: '2px', backgroundColor: 'var(--border-color)' }}></div>
              )}
              <div style={{ width: '16px', height: '16px', borderRadius: '50%', backgroundColor: 'var(--bg-secondary)', border: '2px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1, marginTop: '2px' }}>
                <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'var(--primary-blue)' }}></div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{t.event}</div>
                  <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{new Date(t.date).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</div>
                </div>
                {t.details && (
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>{t.details}</div>
                )}
                <div style={{ fontSize: '10px', color: 'var(--text-light)', marginTop: '4px' }}>By: {t.user}</div>
              </div>
            </div>
          ))
        ) : (
          <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>No timeline events found.</div>
        )}
      </div>
    </div>
  );
};
