import React, { useState } from 'react';
import { PhoneCall, Check, Clock, Save } from 'lucide-react';

export const CallVerificationPanel = ({ employee, onUpdate }) => {
  const [callStatus, setCallStatus] = useState('Not Started');
  const [remarks, setRemarks] = useState('');

  const handleSaveLog = () => {
    // Trigger update up to the workspace component
    if (onUpdate) {
      onUpdate({
        type: 'call-log',
        status: callStatus,
        remarks: remarks,
        timestamp: new Date().toISOString()
      });
      setRemarks('');
    }
  };

  return (
    <div className="card" style={{ padding: '20px', backgroundColor: '#fff', marginBottom: '24px' }}>
      <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <PhoneCall size={18} color="var(--primary-blue)" /> Call Verification Center
      </h3>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        <div>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '8px' }}>Call Status</label>
            <select 
              className="select-input" 
              value={callStatus} 
              onChange={(e) => setCallStatus(e.target.value)}
              style={{ width: '100%', padding: '10px' }}
            >
              <option value="Not Started">Not Started</option>
              <option value="Attempted">Attempted</option>
              <option value="Connected">Connected</option>
              <option value="Verified">Verified</option>
            </select>
          </div>

          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '8px' }}>Call Remarks</label>
            <textarea 
              className="input-field" 
              rows="3" 
              placeholder="Enter call outcome details..."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              style={{ width: '100%', padding: '10px', resize: 'vertical' }}
            ></textarea>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="btn btn-primary" onClick={handleSaveLog} style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px' }}>
              <Save size={14} /> Save Call Log
            </button>
            <button className="btn btn-outline" onClick={() => setCallStatus('Connected')} style={{ flex: 1 }}>Mark Connected</button>
            <button className="btn btn-outline" onClick={() => setCallStatus('Verified')} style={{ flex: 1 }}>Mark Verified</button>
          </div>
        </div>

        <div style={{ backgroundColor: 'var(--bg-secondary)', borderRadius: '8px', padding: '16px', border: '1px solid var(--border-color)' }}>
          <h4 style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '12px' }}>Recent Call Logs</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {employee.timeline && employee.timeline.filter(t => t.event.includes('Call')).length > 0 ? (
              employee.timeline.filter(t => t.event.includes('Call')).map((t, idx) => (
                <div key={idx} style={{ padding: '10px', backgroundColor: '#fff', borderRadius: '6px', border: '1px solid var(--border-color)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                    <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-dark)' }}>{t.event}</span>
                    <span style={{ fontSize: '11px', color: 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '4px' }}><Clock size={12} /> {new Date(t.date).toLocaleTimeString([], {timeStyle: 'short'})}</span>
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{t.details || 'No remarks provided.'}</div>
                </div>
              ))
            ) : (
              <div style={{ fontSize: '12px', color: 'var(--text-gray)', textAlign: 'center', padding: '20px 0' }}>No calls logged yet.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
