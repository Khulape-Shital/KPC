import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Briefcase, PhoneCall, KeyRound, CheckCircle2, 
  AlertTriangle, Clock, ChevronRight, Activity, 
  PhoneForwarded, PlaySquare, Inbox, Upload, FileText
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

export const Dashboard = () => {
  const navigate = useNavigate();
  const [assignedEmployees, setAssignedEmployees] = useState([]);
  const [allTimelineEvents, setAllTimelineEvents] = useState([]);

  // Assume logged in as Amitabh S.
  const EXEC_NAME = 'Amitabh S.';

  useEffect(() => {
    mockDb.init();
    const allEmployees = mockDb.getEmployees();
    console.log("ALL EMPLOYEES", allEmployees);
    
    // Filter cases assigned to this executive
    const myCases = allEmployees.filter(emp => {
      const assignmentEvent = emp.timeline?.find(t => t.event === 'Executive Assigned');
      return assignmentEvent && assignmentEvent.details === EXEC_NAME;
    });
    
    setAssignedEmployees(myCases);

    // Extract all timeline events for this executive's cases for Today's Activity Timeline
    let events = [];
    myCases.forEach(emp => {
      if (emp.timeline) {
        emp.timeline.forEach(t => {
          events.push({
            ...t,
            empId: emp.id,
            empName: emp.name
          });
        });
      }
    });
    // Sort descending by date
    events.sort((a, b) => new Date(b.date) - new Date(a.date));
    setAllTimelineEvents(events.slice(0, 10)); // Top 10 recent
  }, []);

  // Metrics calculation
  const totalAssigned = assignedEmployees.length;
  const inProgress = assignedEmployees.filter(e => e.status === 'in-progress').length;
  const callsPending = assignedEmployees.filter(e => e.status === 'call-pending' || e.status === 'assigned').length;
  const otpPending = assignedEmployees.filter(e => e.status === 'otp-received').length;
  
  // Completed today
  const today = new Date().toISOString().split('T')[0];
  const completedToday = assignedEmployees.filter(e => {
    if (e.status !== 'completed' && e.status !== 'approved' && e.status !== 'rejected') return false;
    const completionEvent = e.timeline?.find(t => t.event === 'Verification Completed' || t.event === 'Verification Approved' || t.event === 'Verification Rejected');
    if (completionEvent) {
      return completionEvent.date.startsWith(today);
    }
    return false;
  }).length;

  const slaRiskCases = assignedEmployees.filter(e => 
    e.status !== 'completed' && e.status !== 'approved' && e.status !== 'rejected' &&
    (e.slaStatus === '7+ Days' || e.slaStatus === '4-7 Days' || e.priority === 'Urgent' || e.priority === 'High')
  );

  const getStatusBadge = (status) => {
    switch (status) {
      case 'submitted': return 'badge-submitted';
      case 'assigned': return 'badge-assigned';
      case 'call-pending': return 'badge-call-pending';
      case 'otp-received': return 'badge-otp-received';
      case 'in-progress': return 'badge-in-progress';
      case 'approved': return 'badge-approved';
      case 'rejected': return 'badge-rejected';
      case 'completed': return 'badge-completed';
      case 'escalated': return 'badge-rejected';
      default: return 'badge-assigned';
    }
  };

  const getSlaRiskColor = (status, priority) => {
    if (status === '7+ Days' || priority === 'Urgent') return '#ef4444'; // Red
    if (status === '4-7 Days' || priority === 'High') return '#f59e0b'; // Amber
    return '#10b981'; // Green
  };

  return (
    <div className="dashboard-container" style={{ display: 'flex', flexDirection: 'column', gap: '24px', animation: 'fadeIn 0.5s ease-out' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, letterSpacing: '-0.5px', color: 'var(--text-dark)' }}>Executive Workspace</h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '4px' }}>Manage your daily verifications, calls, and pending tasks.</p>
        </div>
      </div>

      {/* TOP METRIC CARDS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '16px' }}>
        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #0369a1' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Assigned Cases</span>
            <Briefcase size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{totalAssigned}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Total active queue</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #3b82f6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>In Progress</span>
            <Activity size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{inProgress}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Currently processing</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #8b5cf6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Calls Pending</span>
            <PhoneCall size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{callsPending}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Requires outreach</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #eab308' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>OTP Pending</span>
            <KeyRound size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{otpPending}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Awaiting code</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #10b981' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Completed Today</span>
            <CheckCircle2 size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{completedToday}</div>
          <div style={{ fontSize: '11px', color: '#10b981', marginTop: '4px', fontWeight: 600 }}>+ Daily target</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', borderTop: '4px solid #ef4444' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>SLA Risk</span>
            <AlertTriangle size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{slaRiskCases.length}</div>
          <div style={{ fontSize: '11px', color: '#ef4444', marginTop: '4px', fontWeight: 600 }}>Action required</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '8fr 4fr', gap: '24px', alignItems: 'start' }}>
        
        {/* Left Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* QUICK ACTION CENTER */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', textTransform: 'uppercase', letterSpacing: '1px' }}>Quick Actions</h3>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
              <button className="btn btn-primary" onClick={() => navigate('/exec/tasks/available')} style={{ flex: 1, padding: '10px', fontSize: '13px', display: 'flex', justifyContent: 'center', gap: '6px' }}>
                <Inbox size={16} /> Available Tasks
              </button>
              <button className="btn btn-outline" onClick={() => navigate('/exec/tasks/mine')} style={{ flex: 1, padding: '10px', fontSize: '13px', display: 'flex', justifyContent: 'center', gap: '6px' }}>
                <PlaySquare size={16} /> Resume Last
              </button>
              <button className="btn btn-outline" onClick={() => navigate('/exec/tasks/mine')} style={{ flex: 1, padding: '10px', fontSize: '13px', display: 'flex', justifyContent: 'center', gap: '6px' }}>
                <PhoneForwarded size={16} /> Pending Calls
              </button>
              <button className="btn btn-outline" onClick={() => navigate('/exec/tasks/mine')} style={{ flex: 1, padding: '10px', fontSize: '13px', display: 'flex', justifyContent: 'center', gap: '6px' }}>
                <Upload size={16} /> Upload Pending
              </button>
            </div>
          </div>

          {/* MY ACTIVE CASES TABLE */}
          <div className="card" style={{ padding: '24px', backgroundColor: '#fff', overflowX: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)' }}>My Active Cases</h3>
              <button className="btn btn-outline" onClick={() => navigate('/exec/tasks/mine')} style={{ padding: '6px 12px', fontSize: '12px' }}>
                View All <ChevronRight size={14} style={{ marginLeft: '4px' }} />
              </button>
            </div>

            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-color)', backgroundColor: '#f8fafc' }}>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>EMPLOYEE</th>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>COMPANY</th>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SERVICE TYPE</th>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>STATUS</th>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SLA AGING</th>
                  <th style={{ padding: '12px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {assignedEmployees.filter(e => e.status !== 'completed' && e.status !== 'approved' && e.status !== 'rejected').map(emp => (
                  <tr key={emp.id} className="table-row-hover" style={{ borderBottom: '1px solid var(--border-color)' }}>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 600, fontSize: '13px', color: 'var(--text-dark)' }}>{emp.name}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{emp.id}</div>
                    </td>
                    <td style={{ padding: '12px', fontSize: '13px', color: 'var(--text-gray)' }}>Acme Corp</td>
                    <td style={{ padding: '12px', fontSize: '13px' }}>Identity Verification</td>
                    <td style={{ padding: '12px' }}>
                      <span className={`badge ${getStatusBadge(emp.status)}`}>{emp.status.replace('-', ' ')}</span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span style={{ 
                        fontSize: '12px', 
                        fontWeight: 600, 
                        color: getSlaRiskColor(emp.slaStatus, emp.priority),
                        backgroundColor: `${getSlaRiskColor(emp.slaStatus, emp.priority)}15`,
                        padding: '4px 8px',
                        borderRadius: '4px'
                      }}>
                        {emp.slaStatus || 'On Track'}
                      </span>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <button 
                        className="btn btn-secondary" 
                        onClick={() => navigate(`/exec/workspace/${emp.id}`)}
                        style={{ padding: '6px 10px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        <PlaySquare size={14} /> Open
                      </button>
                    </td>
                  </tr>
                ))}
                {assignedEmployees.filter(e => e.status !== 'completed' && e.status !== 'approved' && e.status !== 'rejected').length === 0 && (
                  <tr>
                    <td colSpan="6" style={{ padding: '24px', textAlign: 'center', color: 'var(--text-gray)', fontSize: '13px' }}>
                      No active cases. Check Available Tasks.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

        </div>

        {/* Right Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* CALL PERFORMANCE PANEL */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <PhoneCall size={16} color="var(--primary-blue)" /> Call Performance
            </h3>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>
              <div style={{ padding: '12px', backgroundColor: '#f8fafc', borderRadius: '8px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '20px', fontWeight: 700, color: 'var(--text-dark)' }}>12</div>
                <div style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600, marginTop: '2px' }}>Calls Today</div>
              </div>
              <div style={{ padding: '12px', backgroundColor: '#f8fafc', borderRadius: '8px', border: '1px solid var(--border-color)', textAlign: 'center' }}>
                <div style={{ fontSize: '20px', fontWeight: 700, color: '#10b981' }}>85%</div>
                <div style={{ fontSize: '11px', color: 'var(--text-gray)', fontWeight: 600, marginTop: '2px' }}>Connected</div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderTop: '1px solid var(--border-color)' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>Avg Call Duration</span>
              <span style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>2m 45s</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderTop: '1px solid var(--border-color)' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>OTP Success Rate</span>
              <span style={{ fontSize: '13px', fontWeight: 600, color: '#10b981' }}>92%</span>
            </div>
          </div>

          {/* SLA RISK PANEL */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: '#ef4444', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <AlertTriangle size={16} /> SLA Risk Watchlist
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {slaRiskCases.length === 0 ? (
                <div style={{ fontSize: '13px', color: 'var(--text-gray)', textAlign: 'center', padding: '12px' }}>No cases at SLA risk.</div>
              ) : (
                slaRiskCases.map(emp => (
                  <div key={emp.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', border: '1px solid #fca5a5', backgroundColor: '#fef2f2', borderRadius: '6px' }}>
                    <div>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: '#991b1b' }}>{emp.name}</div>
                      <div style={{ fontSize: '11px', color: '#b91c1c', marginTop: '2px' }}>{emp.slaStatus} • {emp.priority}</div>
                    </div>
                    <button 
                      onClick={() => navigate(`/exec/workspace/${emp.id}`)}
                      style={{ background: 'transparent', border: '1px solid #f87171', color: '#dc2626', padding: '4px 8px', borderRadius: '4px', fontSize: '11px', cursor: 'pointer', fontWeight: 600 }}
                    >
                      Resolve
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* TODAY'S ACTIVITY TIMELINE */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff', flex: 1 }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Clock size={16} color="var(--primary-blue)" /> Recent Activity
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', position: 'relative' }}>
              {allTimelineEvents.length === 0 ? (
                <div style={{ fontSize: '13px', color: 'var(--text-gray)' }}>No recent activity.</div>
              ) : (
                allTimelineEvents.map((evt, idx) => (
                  <div key={idx} style={{ display: 'flex', gap: '12px', position: 'relative' }}>
                    {idx !== allTimelineEvents.length - 1 && (
                      <div style={{ position: 'absolute', top: '24px', left: '11px', bottom: '-16px', width: '2px', backgroundColor: 'var(--border-color)' }}></div>
                    )}
                    <div style={{ width: '24px', height: '24px', borderRadius: '50%', backgroundColor: 'var(--bg-secondary)', border: '2px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1 }}>
                      <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: 'var(--primary-blue)' }}></div>
                    </div>
                    <div style={{ flex: 1, paddingBottom: '4px' }}>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{evt.event}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>{evt.empName} • {new Date(evt.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
