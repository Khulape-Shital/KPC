import React, { useState } from 'react';
import { Download, Calendar, BarChart2, PieChart, LineChart, FileText, TrendingUp, Search } from 'lucide-react';

export const Reports = () => {
  const [activeTab, setActiveTab] = useState('Operational');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>Reports & Analytics</h1>
          <p style={{ color: 'var(--text-gray)' }}>System-wide analytics, client performance, and financial reporting.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <div className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: '#fff' }}>
            <Calendar size={16} /> Last 30 Days (Oct 01 - Oct 31)
          </div>
          <button className="btn btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Download size={16} /> Export Report (PDF/CSV)</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '32px', borderBottom: '1px solid var(--border-color)' }}>
        {['Operational', 'Client', 'Executive', 'Financial'].map(tab => (
          <button 
            key={tab} 
            onClick={() => setActiveTab(tab)}
            style={{ 
              padding: '12px 0', 
              background: 'none', 
              border: 'none', 
              borderBottom: activeTab === tab ? '2px solid var(--primary-blue)' : '2px solid transparent',
              color: activeTab === tab ? 'var(--primary-blue)' : 'var(--text-gray)',
              fontWeight: activeTab === tab ? 600 : 500,
              cursor: 'pointer',
              fontSize: '14px'
            }}>
            {tab} Reports
          </button>
        ))}
      </div>

      {/* Tab Contents */}
      {activeTab === 'Operational' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
            <div className="card" style={{ padding: '20px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>VERIFICATION VOLUME</div>
              <div style={{ fontSize: '28px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
                4,204 <TrendingUp size={20} color="#166534" />
              </div>
            </div>
            <div className="card" style={{ padding: '20px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>SLA COMPLIANCE</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: '#166534' }}>94.2%</div>
            </div>
            <div className="card" style={{ padding: '20px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>AVG TURNAROUND</div>
              <div style={{ fontSize: '28px', fontWeight: 700 }}>3.4 Days</div>
            </div>
            <div className="card" style={{ padding: '20px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>TOTAL REJECTIONS</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: '#dc2626' }}>112</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
            <div className="card" style={{ padding: '24px' }}>
              <h2 style={{ fontSize: '16px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px' }}><BarChart2 size={18} color="var(--primary-blue)" /> Volume Trend Analysis</h2>
              <div style={{ height: '250px', backgroundColor: '#f8fafc', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-gray)' }}>
                [ Bar Chart Visualization: Oct 01 - Oct 31 Volume ]
              </div>
            </div>
            <div className="card" style={{ padding: '24px' }}>
              <h2 style={{ fontSize: '16px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px' }}><PieChart size={18} color="var(--primary-blue)" /> Status Distribution</h2>
              <div style={{ height: '250px', backgroundColor: '#f8fafc', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-gray)' }}>
                [ Pie Chart Visualization: Statuses ]
              </div>
            </div>
          </div>
          
          <div className="card" style={{ padding: '24px' }}>
            <h2 style={{ fontSize: '16px', marginBottom: '24px' }}>Aging Analysis Summary</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-gray)', fontSize: '12px' }}>
                  <th style={{ paddingBottom: '12px' }}>SERVICE CATEGORY</th>
                  <th style={{ paddingBottom: '12px' }}>1-3 DAYS</th>
                  <th style={{ paddingBottom: '12px' }}>4-7 DAYS</th>
                  <th style={{ paddingBottom: '12px' }}>7+ DAYS (BREACH)</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>Identity Verification</td>
                  <td style={{ padding: '16px 0' }}>450</td>
                  <td style={{ padding: '16px 0' }}>120</td>
                  <td style={{ padding: '16px 0', color: '#dc2626', fontWeight: 600 }}>14</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>Police Verification</td>
                  <td style={{ padding: '16px 0' }}>200</td>
                  <td style={{ padding: '16px 0' }}>85</td>
                  <td style={{ padding: '16px 0', color: '#dc2626', fontWeight: 600 }}>42</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'Client' && (
        <div className="card" style={{ padding: '24px' }}>
          <h2 style={{ fontSize: '16px', marginBottom: '24px' }}>Client Performance & Verification Summary</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-gray)', fontSize: '12px' }}>
                  <th style={{ paddingBottom: '12px' }}>CLIENT ACCOUNT</th>
                  <th style={{ paddingBottom: '12px' }}>TOTAL FORMS</th>
                  <th style={{ paddingBottom: '12px' }}>COMPLETED</th>
                  <th style={{ paddingBottom: '12px' }}>SLA COMPLIANCE</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>TechCorp Solutions</td>
                  <td style={{ padding: '16px 0' }}>1,204</td>
                  <td style={{ padding: '16px 0' }}>1,150</td>
                  <td style={{ padding: '16px 0', color: '#166534', fontWeight: 600 }}>98%</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>Vertex Group</td>
                  <td style={{ padding: '16px 0' }}>450</td>
                  <td style={{ padding: '16px 0' }}>410</td>
                  <td style={{ padding: '16px 0', color: '#ea580c', fontWeight: 600 }}>88%</td>
                </tr>
              </tbody>
            </table>
        </div>
      )}

      {activeTab === 'Financial' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          <div className="card" style={{ padding: '24px' }}>
             <h2 style={{ fontSize: '16px', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '8px' }}><LineChart size={18} color="var(--primary-blue)" /> Revenue Summary</h2>
             <div style={{ height: '300px', backgroundColor: '#f8fafc', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-gray)' }}>
                [ Line Chart Visualization: MoM Revenue Growth ]
             </div>
          </div>
        </div>
      )}

      {activeTab === 'Executive' && (
        <div className="card" style={{ padding: '24px' }}>
          <h2 style={{ fontSize: '16px', marginBottom: '24px' }}>Executive Performance Ranking</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-gray)', fontSize: '12px' }}>
                  <th style={{ paddingBottom: '12px' }}>RANK</th>
                  <th style={{ paddingBottom: '12px' }}>EXECUTIVE</th>
                  <th style={{ paddingBottom: '12px' }}>PRODUCTIVITY (CASES/MO)</th>
                  <th style={{ paddingBottom: '12px' }}>SLA RANKING</th>
                </tr>
              </thead>
              <tbody>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 700, color: 'var(--primary-blue)' }}>#1</td>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>Amitabh S.</td>
                  <td style={{ padding: '16px 0' }}>145</td>
                  <td style={{ padding: '16px 0', color: '#166534', fontWeight: 600 }}>98%</td>
                </tr>
                <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '16px 0', fontWeight: 700 }}>#2</td>
                  <td style={{ padding: '16px 0', fontWeight: 600 }}>Neha Gupta</td>
                  <td style={{ padding: '16px 0' }}>130</td>
                  <td style={{ padding: '16px 0', color: '#166534', fontWeight: 600 }}>100%</td>
                </tr>
              </tbody>
            </table>
        </div>
      )}

    </div>
  );
};
