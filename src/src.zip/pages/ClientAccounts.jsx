import React, { useState, useEffect } from 'react';
import { Plus, Search, Building, Users, FileText, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockDb } from '../utils/mockDb';

export const ClientAccounts = () => {
  const navigate = useNavigate();
  const [clients, setClients] = useState([]);
  const [search, setSearch] = useState('');
  const [filterIndustry, setFilterIndustry] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  const loadClients = () => {
    setClients(mockDb.getClients());
  };

  useEffect(() => {
    loadClients();
  }, []);

  // Derive active employee count per client from employees
  const getEmployeeCount = (clientName) => {
    const emps = mockDb.getEmployees();
    return emps.filter(e => e.company === clientName).length;
  };

  const industries = [...new Set(clients.map(c => c.industry))].sort();

  const filtered = clients.filter(c => {
    if (filterIndustry && c.industry !== filterIndustry) return false;
    if (filterStatus && c.status !== filterStatus) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!c.name.toLowerCase().includes(s) && !c.id.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 700, marginBottom: '8px' }}>Client Accounts</h1>
          <p style={{ color: 'var(--text-gray)' }}>Manage client companies, HR credentials, and verification services.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-outline" onClick={loadClients} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <RefreshCw size={15} /> Refresh
          </button>
          <button className="btn btn-primary" onClick={() => navigate('/ops/clients/create')} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Plus size={16} /> Create Client
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card" style={{ padding: '16px', display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div className="header-search" style={{ width: '280px', border: '1px solid var(--border-color)', margin: 0, backgroundColor: '#fff' }}>
          <Search size={16} color="var(--text-gray)" />
          <input
            type="text"
            placeholder="Search Client Name or ID"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select
          value={filterIndustry}
          onChange={e => setFilterIndustry(e.target.value)}
          style={{ padding: '9px 12px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '13px', backgroundColor: '#fff', cursor: 'pointer' }}
        >
          <option value="">All Industries</option>
          {industries.map(i => <option key={i} value={i}>{i}</option>)}
        </select>
        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          style={{ padding: '9px 12px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '13px', backgroundColor: '#fff', cursor: 'pointer' }}
        >
          <option value="">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
          <option value="Suspended">Suspended</option>
        </select>
        <span style={{ fontSize: '13px', color: 'var(--text-gray)', marginLeft: 'auto' }}>
          {filtered.length} of {clients.length} clients
        </span>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="card" style={{ padding: '64px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
          <Building size={48} color="var(--text-gray)" style={{ opacity: 0.3 }} />
          <h3 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-dark)' }}>No Clients Found</h3>
          <p style={{ fontSize: '13px', color: 'var(--text-gray)' }}>No clients match your search. Create the first client account to get started.</p>
          <button className="btn btn-primary" onClick={() => navigate('/ops/clients/create')}>
            <Plus size={16} /> Create Client Account
          </button>
        </div>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>CLIENT</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>INDUSTRY & HQ</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>SERVICES</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>HR ACCOUNTS</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>EMPLOYEES</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>STATUS</th>
                <th style={{ padding: '14px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px', textAlign: 'right' }}>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((client) => {
                const empCount = getEmployeeCount(client.name);
                return (
                  <tr
                    key={client.id}
                    className="table-row-hover"
                    style={{ borderBottom: '1px solid var(--border-color)', cursor: 'pointer' }}
                    onClick={() => navigate(`/ops/clients/${client.id}`)}
                  >
                    <td style={{ padding: '16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div className="avatar" style={{ backgroundColor: 'var(--primary-blue-light)', color: 'var(--primary-blue)', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          <Building size={18} />
                        </div>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text-dark)' }}>{client.name}</div>
                          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>ID: {client.id}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '16px', fontSize: '14px' }}>
                      <div style={{ fontWeight: 500, color: 'var(--text-dark)' }}>{client.industry}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>{client.hq}</div>
                    </td>
                    <td style={{ padding: '16px' }}>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {(client.services || []).slice(0, 2).map(s => (
                          <span key={s} style={{ fontSize: '10px', fontWeight: 600, padding: '2px 8px', borderRadius: '10px', backgroundColor: 'var(--primary-blue-light)', color: 'var(--primary-blue)' }}>
                            {s.replace(' Verification', '')}
                          </span>
                        ))}
                        {(client.services || []).length > 2 && (
                          <span style={{ fontSize: '10px', fontWeight: 600, padding: '2px 8px', borderRadius: '10px', backgroundColor: '#f1f5f9', color: 'var(--text-gray)' }}>
                            +{client.services.length - 2}
                          </span>
                        )}
                      </div>
                    </td>
                    <td style={{ padding: '16px', fontSize: '14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <Users size={16} color="var(--text-gray)" />
                        <span style={{ fontWeight: 500 }}>{(client.hrAccounts || []).length}</span>
                        <span style={{ color: 'var(--text-gray)', fontSize: '12px' }}>users</span>
                      </div>
                    </td>
                    <td style={{ padding: '16px', fontSize: '14px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <FileText size={16} color="var(--text-gray)" />
                        <span style={{ fontWeight: 500 }}>{empCount}</span>
                        <span style={{ color: 'var(--text-gray)', fontSize: '12px' }}>forms</span>
                      </div>
                    </td>
                    <td style={{ padding: '16px' }}>
                      <span className={client.status === 'Active' ? 'badge badge-completed' : 'badge badge-rejected'}>
                        {client.status}
                      </span>
                    </td>
                    <td style={{ padding: '16px', textAlign: 'right' }} onClick={e => e.stopPropagation()}>
                      <button
                        className="btn btn-outline"
                        onClick={() => navigate(`/ops/clients/${client.id}`)}
                        style={{ padding: '6px 14px', fontSize: '12px' }}
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
