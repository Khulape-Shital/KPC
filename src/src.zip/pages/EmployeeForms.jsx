import React, { useState } from 'react';
import { Download, Layers, Search, Calendar, Eye, CheckCircle2, XCircle, FileText, ChevronDown, X, Clock, User, CheckSquare, AlertCircle, History } from 'lucide-react';

const DOC_TYPES = [
  { id: 'aadhaar', label: 'A', tooltip: 'Aadhaar Card' },
  { id: 'pan', label: 'P', tooltip: 'PAN Card' },
  { id: 'voter', label: 'V', tooltip: 'Voter ID' },
  { id: 'birth', label: 'B', tooltip: 'Birth Certificate' },
  { id: 'school', label: 'S', tooltip: 'School Leaving' },
  { id: 'address', label: 'Ad', tooltip: 'Address Proof' },
];

const STATUS_WORKFLOW = {
  'submitted': ['assigned'],
  'assigned': ['call-pending'],
  'call-pending': ['otp-received', 'rejected'],
  'otp-received': ['in-progress', 'rejected'],
  'in-progress': ['approved', 'rejected'],
  'approved': ['completed'],
  'rejected': [],
  'completed': []
};

const INITIAL_DATA = [
  { 
    id: '#E-90421', name: 'Rajiv Jhunjhunwala', company: 'TechCorp Solutions', service: 'Identity + Education', 
    date: 'Oct 24, 2023', assigned: 'Amitabh S.', workload: 12, status: 'in-progress', statusLabel: 'In Progress',
    docs: ['aadhaar', 'pan', 'school', 'address'], priority: 'Urgent', sla: '7+ Days',
    audit: [
      { user: 'Client HR', action: 'Form Created', date: 'Oct 24, 2023 10:00 AM' },
      { user: 'Operations Manager', action: 'Executive Assigned (Amitabh S.)', date: 'Oct 24, 2023 11:30 AM' },
      { user: 'Amitabh S.', action: 'Status Changed to In Progress', date: 'Oct 25, 2023 09:15 AM' }
    ]
  },
  { 
    id: '#E-90422', name: 'Priya Kulkarni', company: 'Vertex Group', service: 'Criminal Record', 
    date: 'Oct 22, 2023', assigned: 'Sanjay V.', workload: 8, status: 'completed', statusLabel: 'Completed',
    docs: ['aadhaar', 'pan', 'voter', 'birth', 'school', 'address'], priority: 'Medium', sla: '1-3 Days',
    audit: [
      { user: 'Client HR', action: 'Form Created', date: 'Oct 22, 2023 02:00 PM' },
      { user: 'Sanjay V.', action: 'Status Changed to Completed', date: 'Oct 23, 2023 04:45 PM' }
    ]
  },
  { 
    id: '#E-90423', name: 'Anish Sharma', company: 'Innovate Global', service: 'Address Check', 
    date: 'Oct 25, 2023', assigned: 'Unassigned', workload: null, status: 'submitted', statusLabel: 'Submitted',
    docs: ['aadhaar', 'address'], priority: 'Low', sla: 'Submitted Today',
    audit: [
      { user: 'Client HR', action: 'Form Created', date: 'Today 09:00 AM' }
    ]
  },
];

const getPriorityColor = (priority) => {
  switch (priority) {
    case 'Urgent': return '#dc2626'; // Red
    case 'High': return '#ea580c'; // Orange
    case 'Medium': return '#0284c7'; // Blue
    case 'Low': return '#64748b'; // Gray
    default: return '#64748b';
  }
};

const getSlaColor = (sla) => {
  switch (sla) {
    case '7+ Days': return '#fef2f2'; // Red BG
    case '4-7 Days': return '#fff7ed'; // Orange BG
    case '1-3 Days': return '#f0fdf4'; // Green BG
    case 'Submitted Today': return '#f8fafc'; // Gray BG
    default: return 'transparent';
  }
};

const getSlaTextColor = (sla) => {
  switch (sla) {
    case '7+ Days': return '#991b1b'; // Red Text
    case '4-7 Days': return '#9a3412'; // Orange Text
    case '1-3 Days': return '#166534'; // Green Text
    case 'Submitted Today': return '#475569'; // Gray Text
    default: return '#000';
  }
};

export const EmployeeForms = () => {
  const [data, setData] = useState(INITIAL_DATA);
  const [search, setSearch] = useState('');
  const [filterCompany, setFilterCompany] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterPriority, setFilterPriority] = useState('All');
  const [selectedRows, setSelectedRows] = useState([]);
  const [bulkMenuOpen, setBulkMenuOpen] = useState(false);
  const [modalData, setModalData] = useState(null);

  const filteredData = data.filter(row => {
    const matchSearch = row.name.toLowerCase().includes(search.toLowerCase()) || row.id.toLowerCase().includes(search.toLowerCase());
    const matchCompany = filterCompany === 'All' || row.company === filterCompany;
    const matchStatus = filterStatus === 'All' || row.statusLabel === filterStatus;
    const matchPriority = filterPriority === 'All' || row.priority === filterPriority;
    return matchSearch && matchCompany && matchStatus && matchPriority;
  });

  const handleSelectAll = (e) => {
    if (e.target.checked) setSelectedRows(filteredData.map(r => r.id));
    else setSelectedRows([]);
  };

  const handleSelectRow = (id) => {
    if (selectedRows.includes(id)) setSelectedRows(selectedRows.filter(r => r !== id));
    else setSelectedRows([...selectedRows, id]);
  };

  const updateStatus = (rowId, newStatusId, newStatusLabel) => {
    const row = data.find(r => r.id === rowId);
    if (!STATUS_WORKFLOW[row.status].includes(newStatusId)) {
      alert(`Invalid transition from ${row.status} to ${newStatusId}.`);
      return;
    }
    
    const newAuditEntry = { user: 'Operations Manager', action: `Status Changed to ${newStatusLabel}`, date: 'Just now' };
    const updatedRows = data.map(r => r.id === rowId ? { 
      ...r, 
      status: newStatusId, 
      statusLabel: newStatusLabel,
      audit: [newAuditEntry, ...r.audit]
    } : r);
    
    setData(updatedRows);
    if (modalData) {
      setModalData(updatedRows.find(r => r.id === rowId));
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>Employee Forms</h1>
          <p style={{ color: 'var(--text-gray)' }}>Manage and monitor employee verification submissions.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px', position: 'relative' }}>
          <button className="btn btn-outline">
            <Download size={16} style={{ marginRight: '8px' }} /> Export Data
          </button>
          <div style={{ position: 'relative' }}>
            <button className="btn btn-primary" onClick={() => setBulkMenuOpen(!bulkMenuOpen)}>
              <Layers size={16} style={{ marginRight: '8px' }} /> Bulk Actions <ChevronDown size={16} style={{ marginLeft: '4px' }}/>
            </button>
            {bulkMenuOpen && (
              <div className="card" style={{ position: 'absolute', top: '100%', right: 0, marginTop: '8px', zIndex: 10, width: '200px', padding: '8px 0' }}>
                <button style={{ display: 'block', width: '100%', textAlign: 'left', padding: '8px 16px', borderBottom: '1px solid var(--border-color)' }}>Bulk Export</button>
                <button style={{ display: 'block', width: '100%', textAlign: 'left', padding: '8px 16px', borderBottom: '1px solid var(--border-color)' }}>Bulk Status Update</button>
                <button style={{ display: 'block', width: '100%', textAlign: 'left', padding: '8px 16px' }}>Bulk Assignment</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="card" style={{ padding: '16px', display: 'flex', gap: '16px', alignItems: 'center' }}>
        <div className="header-search" style={{ width: '250px', border: '1px solid var(--border-color)', margin: 0, backgroundColor: '#fff' }}>
          <Search size={16} color="var(--text-gray)" />
          <input type="text" placeholder="Search ID or Name" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <option value="All">All Companies</option>
          <option value="TechCorp Solutions">TechCorp</option>
          <option value="Vertex Group">Vertex</option>
        </select>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <option value="All">All Statuses</option>
          <option value="Submitted">Submitted</option>
          <option value="Assigned">Assigned</option>
          <option value="In Progress">In Progress</option>
          <option value="Completed">Completed</option>
        </select>
        <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <option value="All">All Priorities</option>
          <option value="Urgent">Urgent</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        {filteredData.length === 0 ? (
          <div style={{ padding: '64px', textAlign: 'center' }}>
            <FileText size={48} color="var(--text-light)" style={{ marginBottom: '16px', display: 'inline-block' }} />
            <h3 style={{ fontSize: '18px', marginBottom: '8px' }}>No Forms Found</h3>
            <p style={{ color: 'var(--text-gray)', marginBottom: '16px' }}>Try adjusting your search or filters to find what you're looking for.</p>
            <button className="btn btn-outline" onClick={() => { setSearch(''); setFilterCompany('All'); setFilterStatus('All'); setFilterPriority('All'); }}>Clear Filters</button>
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '16px' }}><input type="checkbox" onChange={handleSelectAll} checked={selectedRows.length === filteredData.length && filteredData.length > 0} /></th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>EMPLOYEE</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>PRIORITY & SLA</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>DOCUMENTS</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>ASSIGNMENT</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>STATUS</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((row) => (
                <tr key={row.id} style={{ borderBottom: '1px solid var(--border-color)', backgroundColor: selectedRows.includes(row.id) ? 'var(--bg-hover)' : 'transparent' }}>
                  <td style={{ padding: '16px' }}><input type="checkbox" checked={selectedRows.includes(row.id)} onChange={() => handleSelectRow(row.id)} /></td>
                  <td style={{ padding: '16px' }}>
                    <div style={{ fontWeight: 600 }}>{row.name}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{row.id} • {row.company}</div>
                  </td>
                  <td style={{ padding: '16px' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-start' }}>
                      <span style={{ fontSize: '12px', fontWeight: 600, color: getPriorityColor(row.priority) }}>{row.priority}</span>
                      <span style={{ fontSize: '11px', padding: '2px 6px', borderRadius: '4px', backgroundColor: getSlaColor(row.sla), color: getSlaTextColor(row.sla) }}>{row.sla}</span>
                    </div>
                  </td>
                  <td style={{ padding: '16px' }}>
                    <div style={{ display: 'flex', gap: '4px' }}>
                      {DOC_TYPES.map(doc => {
                        const hasDoc = row.docs.includes(doc.id);
                        return (
                          <div key={doc.id} title={doc.tooltip} style={{
                            width: '24px', height: '24px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center',
                            fontSize: '10px', fontWeight: 600,
                            backgroundColor: hasDoc ? 'var(--primary-blue-light)' : '#f1f5f9',
                            color: hasDoc ? 'var(--primary-blue)' : '#cbd5e1',
                            border: `1px solid ${hasDoc ? 'var(--primary-blue)' : 'transparent'}`
                          }}>
                            {doc.label}
                          </div>
                        )
                      })}
                    </div>
                  </td>
                  <td style={{ padding: '16px', fontSize: '14px' }}>
                    {row.assigned === 'Unassigned' ? (
                      <span style={{ color: '#dc2626', fontWeight: 600 }}>Unassigned</span>
                    ) : (
                      <div>
                        <div style={{ fontWeight: 600 }}>{row.assigned}</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{row.workload} Active Cases</div>
                      </div>
                    )}
                  </td>
                  <td style={{ padding: '16px' }}>
                    <span className={`badge badge-${row.status}`}>{row.statusLabel}</span>
                  </td>
                  <td style={{ padding: '16px' }}>
                    <button className="btn btn-outline" onClick={() => setModalData(row)} style={{ padding: '4px 8px', fontSize: '12px' }}>
                      <Eye size={14} style={{ marginRight: '4px' }} /> View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Employee Details Drawer/Modal */}
      {modalData && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 50, display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ width: '600px', backgroundColor: '#fff', height: '100%', boxShadow: '-4px 0 15px rgba(0,0,0,0.1)', display: 'flex', flexDirection: 'column' }}>
            
            <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <h2 style={{ fontSize: '20px', margin: 0 }}>{modalData.name}</h2>
                  <span style={{ fontSize: '12px', padding: '2px 8px', borderRadius: '12px', border: `1px solid ${getPriorityColor(modalData.priority)}`, color: getPriorityColor(modalData.priority), fontWeight: 600 }}>{modalData.priority} Priority</span>
                </div>
                <div style={{ color: 'var(--text-gray)', fontSize: '14px' }}>{modalData.id} • {modalData.company}</div>
              </div>
              <button onClick={() => setModalData(null)} style={{ padding: '8px' }}><X size={20} /></button>
            </div>

            <div style={{ padding: '24px', overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="card" style={{ padding: '16px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px' }}>SLA AGING</div>
                  <div style={{ fontWeight: 600, color: getSlaTextColor(modalData.sla) }}>{modalData.sla}</div>
                </div>
                <div className="card" style={{ padding: '16px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px' }}>ASSIGNMENT</div>
                  <div style={{ fontWeight: 600, color: modalData.assigned === 'Unassigned' ? '#dc2626' : 'inherit' }}>
                    {modalData.assigned} {modalData.workload && `(${modalData.workload} Cases)`}
                  </div>
                </div>
              </div>

              <div className="card" style={{ padding: '16px' }}>
                <h3 style={{ fontSize: '14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <CheckSquare size={16} color="var(--primary-blue)" /> Workflow Status
                </h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className={`badge badge-${modalData.status}`} style={{ fontSize: '14px', padding: '6px 12px' }}>{modalData.statusLabel}</span>
                  
                  <div style={{ display: 'flex', gap: '8px' }}>
                    {STATUS_WORKFLOW[modalData.status].map(nextStatus => (
                      <button key={nextStatus} className="btn btn-outline" onClick={() => updateStatus(modalData.id, nextStatus, nextStatus.replace('-', ' ').toUpperCase())} style={{ fontSize: '12px' }}>
                        Move to {nextStatus}
                      </button>
                    ))}
                    {STATUS_WORKFLOW[modalData.status].length === 0 && <span style={{ fontSize: '12px', color: 'var(--text-gray)' }}>Final State Reached</span>}
                  </div>
                </div>
              </div>

              <div className="card" style={{ padding: '16px' }}>
                <h3 style={{ fontSize: '14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <History size={16} color="var(--primary-blue)" /> Audit Trail
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {modalData.audit.map((entry, idx) => (
                    <div key={idx} style={{ display: 'flex', gap: '12px', borderBottom: idx !== modalData.audit.length - 1 ? '1px solid var(--border-color)' : 'none', paddingBottom: idx !== modalData.audit.length - 1 ? '12px' : 0 }}>
                      <div className="avatar" style={{ width: '32px', height: '32px', fontSize: '12px', backgroundColor: '#e2e8f0', color: '#475569' }}>
                        {entry.user.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 600 }}>{entry.action}</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{entry.user} • {entry.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};
