import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  PlusCircle, Clock, AlertTriangle, CheckCircle2, 
  Users, FileText, ArrowRight, TrendingUp, 
  Layers, CheckSquare, BellRing, Calendar, ChevronRight,
  ShieldCheck, HelpCircle, FileCheck, Eye, MessageSquare
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

export const Dashboard = () => {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [hoveredSegment, setHoveredSegment] = useState(null);

  useEffect(() => {
    mockDb.init();
    setEmployees(mockDb.getEmployees());
    setNotifications(mockDb.getNotifications());
  }, []);

  // Calculate Metrics
  const totalEmployees = employees.length;
  const draftCount = employees.filter(e => e.status === 'draft').length;
  const submittedCount = employees.filter(e => e.status === 'submitted').length;
  const assignedCount = employees.filter(e => e.status === 'assigned').length;
  const inProgressCount = employees.filter(e => 
    ['call-pending', 'otp-received', 'in-progress'].includes(e.status)
  ).length;
  const approvedCount = employees.filter(e => e.status === 'approved').length;
  const rejectedCount = employees.filter(e => e.status === 'rejected').length;
  const completedCount = employees.filter(e => e.status === 'completed').length;
  
  const totalActiveVerifications = submittedCount + assignedCount + inProgressCount;

  // 1. Draft Summary Widget Logic
  const drafts = employees.filter(e => e.status === 'draft');
  const totalDrafts = drafts.length;
  // A draft is awaiting documents if it has less than 2 documents uploaded
  const draftsAwaiting = drafts.filter(e => !e.documents || e.documents.length < 2).length;
  const draftsReady = totalDrafts - draftsAwaiting;

  // 2. Document Validation Summary Logic
  let missingDocs = 0;
  let rejectedDocs = 0;
  let reuploadDocs = 0;

  employees.forEach(emp => {
    // For drafts, check missing mandatory identity proofs (Aadhaar & PAN are mandatory)
    if (emp.status === 'draft') {
      const docTypes = emp.documents ? emp.documents.map(d => d.type) : [];
      if (!docTypes.includes('Aadhaar Card')) missingDocs++;
      if (!docTypes.includes('PAN Card')) missingDocs++;
    }
    if (emp.documents) {
      emp.documents.forEach(doc => {
        if (doc.status === 'Missing') missingDocs++;
        if (doc.status === 'Rejected') rejectedDocs++;
        if (doc.status === 'Re-upload Required') reuploadDocs++;
      });
    }
  });

  // 3. Notification Snapshot Logic
  const unreadNotifsCount = notifications.filter(n => !n.read).length;
  const approvalNotifsCount = notifications.filter(n => n.type === 'completion' || n.type === 'approval').length;
  const rejectionNotifsCount = notifications.filter(n => n.type === 'rejection').length;
  const remarksNotifsCount = notifications.filter(n => n.type === 'remarks').length;
  const notificationFeed = notifications.slice(0, 4);

  // 4. Recent Employee Submissions (Submitted/Active/Completed verifications)
  const recentSubmissions = employees
    .filter(e => e.status !== 'draft')
    .sort((a, b) => new Date(b.submittedDate || b.createdDate) - new Date(a.submittedDate || a.createdDate))
    .slice(0, 5);

  // Status Distribution Chart Data
  const statusData = [
    { label: 'Submitted', count: submittedCount, color: '#f59e0b' },
    { label: 'Assigned', count: assignedCount, color: '#0369a1' },
    { label: 'In Progress', count: inProgressCount, color: '#3b82f6' },
    { label: 'Approved', count: approvedCount, color: '#10b981' },
    { label: 'Rejected', count: rejectedCount, color: '#ef4444' },
    { label: 'Completed', count: completedCount, color: '#06b6d4' }
  ].filter(item => item.count > 0);

  const totalChartCount = statusData.reduce((sum, item) => sum + item.count, 0);

  // SVG Donut calculation
  let accumulatedPercent = 0;
  const donutSegments = statusData.map((item) => {
    const percent = (item.count / totalChartCount) * 100;
    const strokeDash = `${percent} ${100 - percent}`;
    const strokeOffset = 100 - accumulatedPercent + 25; // +25 to start at top (12 o'clock)
    accumulatedPercent += percent;
    return {
      ...item,
      percent,
      strokeDash,
      strokeOffset: strokeOffset % 100
    };
  });

  // Service Type Breakdown dynamic counts
  const serviceCounts = {
    'Aadhaar/PAN Check': 0,
    'Police Verification': 0,
    'Address Check': 0,
    'Academic Check': 0
  };

  employees.forEach(emp => {
    const docTypes = emp.documents ? emp.documents.map(d => d.type) : [];
    if (docTypes.includes('Aadhaar Card') || docTypes.includes('PAN Card')) {
      serviceCounts['Aadhaar/PAN Check']++;
    }
    if (docTypes.includes('Birth Certificate') || docTypes.includes('School Leaving')) {
      serviceCounts['Academic Check']++;
    }
    if (emp.notes && emp.notes.toLowerCase().includes('address')) {
      serviceCounts['Address Check']++;
    } else {
      serviceCounts['Address Check']++;
    }
    if (emp.priority === 'Urgent' || emp.id === 'EMP-90421') {
      serviceCounts['Police Verification']++;
    }
  });

  const serviceData = Object.entries(serviceCounts).map(([name, count]) => ({
    name,
    count,
    percentage: totalEmployees > 0 ? Math.round((count / (totalEmployees * 2)) * 100) : 0
  }));

  const handleQuickAction = (actionType) => {
    switch (actionType) {
      case 'create':
        navigate('/hr/employees/create');
        break;
      case 'pending':
        navigate('/hr/employees', { state: { filterStatus: 'In Progress' } });
        break;
      case 'rejected':
        navigate('/hr/employees', { state: { filterStatus: 'Rejected' } });
        break;
      case 'completed':
        navigate('/hr/employees', { state: { filterStatus: 'Completed' } });
        break;
      default:
        break;
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case 'submitted': return 'badge-submitted';
      case 'assigned': return 'badge-assigned';
      case 'call-pending': return 'badge-call-pending';
      case 'otp-received': return 'badge-otp-received';
      case 'in-progress': return 'badge-in-progress';
      case 'approved': return 'badge-approved';
      case 'rejected': return 'badge-rejected';
      case 'completed': return 'badge-completed';
      default: return '';
    }
  };

  const getServiceType = (emp) => {
    if (emp.id === 'EMP-90421') return 'Identity + Education';
    if (emp.id === 'EMP-90422') return 'Criminal Record';
    if (emp.id === 'EMP-90423') return 'Address Check';
    if (emp.id === 'EMP-90424') return 'Identity Verification';
    return 'Identity Verification';
  };

  return (
    <div className="dashboard-container" style={{ display: 'flex', flexDirection: 'column', gap: '24px', animation: 'fadeIn 0.5s ease-out' }}>
      
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .quick-action-card {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .quick-action-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 20px -8px rgba(11, 75, 175, 0.15);
          border-color: var(--primary-blue);
        }
        .quick-action-card:hover .action-arrow {
          transform: translateX(4px);
          color: var(--primary-blue);
        }
        .metric-card {
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
        }
        .metric-card:hover {
          transform: translateY(-2px);
          box-shadow: var(--shadow-md);
        }
        .metric-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          width: 4px;
          height: 100%;
          background-color: var(--accent-color, var(--primary-blue));
        }
        .activity-row {
          transition: background-color 0.2s ease;
        }
        .activity-row:hover {
          background-color: var(--bg-hover);
        }
        .funnel-stage {
          position: relative;
          flex: 1;
          background: #f1f5f9;
          padding: 12px 8px;
          border-radius: 8px;
          text-align: center;
          border: 1px solid var(--border-color);
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
        }
        .funnel-stage::after {
          content: '→';
          position: absolute;
          right: -14px;
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-light);
          font-weight: bold;
          font-size: 16px;
          z-index: 2;
        }
        .funnel-stage:last-child::after {
          content: '';
        }
      `}</style>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, letterSpacing: '-0.5px', color: 'var(--text-dark)' }}>Client Dashboard</h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '4px' }}>Welcome back! Monitor employee verifications and pending items.</p>
        </div>
        <div className="card" style={{ padding: '8px 16px', display: 'flex', alignItems: 'center', gap: '8px', backgroundColor: '#fff', fontSize: '14px', color: 'var(--text-gray)' }}>
          <Calendar size={16} />
          <span>June 14, 2026</span>
        </div>
      </div>

      {/* HR Dashboard Quick Actions */}
      <div>
        <h2 style={{ fontSize: '14px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-gray)', marginBottom: '12px', fontWeight: 600 }}>Quick Actions</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '16px' }}>
          
          <div className="card quick-action-card" onClick={() => handleQuickAction('create')} style={{ padding: '20px', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#fff' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: 'var(--primary-blue-light)', color: 'var(--primary-blue)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <PlusCircle size={20} />
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '15px', color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                Create Employee <ChevronRight size={16} className="action-arrow" style={{ transition: 'transform 0.2s' }} />
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>Register new employee forms & upload proofs.</p>
            </div>
          </div>

          <div className="card quick-action-card" onClick={() => handleQuickAction('pending')} style={{ padding: '20px', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#fff' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: '#fef3c7', color: '#d97706', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Clock size={20} />
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '15px', color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                View Pending <ChevronRight size={16} className="action-arrow" style={{ transition: 'transform 0.2s' }} />
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>Check verifications currently in progress.</p>
            </div>
          </div>

          <div className="card quick-action-card" onClick={() => handleQuickAction('rejected')} style={{ padding: '20px', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#fff' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: '#fee2e2', color: '#dc2626', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <AlertTriangle size={20} />
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '15px', color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                View Rejected <ChevronRight size={16} className="action-arrow" style={{ transition: 'transform 0.2s' }} />
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>See flagged accounts requiring re-upload.</p>
            </div>
          </div>

          <div className="card quick-action-card" onClick={() => handleQuickAction('completed')} style={{ padding: '20px', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: '12px', backgroundColor: '#fff' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '8px', backgroundColor: '#dcfce7', color: '#166534', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <CheckCircle2 size={20} />
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '15px', color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                View Completed <ChevronRight size={16} className="action-arrow" style={{ transition: 'transform 0.2s' }} />
              </div>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>Download finalized reports & certificates.</p>
            </div>
          </div>

        </div>
      </div>

      {/* Metric Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '16px' }}>
        
        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#0b4baf' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Total Employees</span>
            <Users size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{totalEmployees}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Saved or registered</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Submitted</span>
            <FileText size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{submittedCount}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Awaiting Assignment</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#3b82f6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>In Progress</span>
            <Clock size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{inProgressCount}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Active verification checks</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#10b981' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Approved</span>
            <CheckCircle2 size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{approvedCount}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Verification successful</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#ef4444' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Rejected</span>
            <AlertTriangle size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{rejectedCount}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Requires action</div>
        </div>

        <div className="card metric-card" style={{ padding: '20px', backgroundColor: '#fff', '--accent-color': '#06b6d4' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: 'var(--text-gray)' }}>
            <span style={{ fontSize: '13px', fontWeight: 600 }}>Completed</span>
            <CheckSquare size={18} />
          </div>
          <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', marginTop: '12px' }}>{completedCount}</div>
          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '4px' }}>Reports downloaded</div>
        </div>

      </div>

      {/* Main Grid: Left Side (Funnel & Submissions), Right Side (Draft Summary & Document Validation) */}
      <div style={{ display: 'grid', gridTemplateColumns: '8fr 4fr', gap: '24px', alignItems: 'start' }}>
        
        {/* Left Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* 5. Verification Status Funnel */}
          <div className="card" style={{ padding: '24px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '4px' }}>Verification Status Funnel</h3>
            <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '20px' }}>Global stage analysis of employee case processing stages.</p>
            
            <div style={{ display: 'flex', gap: '20px', justifyContent: 'space-between' }}>
              
              <div className="funnel-stage">
                <span style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)', textTransform: 'uppercase' }}>Draft</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: 'var(--text-dark)' }}>{draftCount}</span>
              </div>

              <div className="funnel-stage" style={{ borderLeftColor: '#f59e0b', borderLeftWidth: '2px' }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: '#b45309', textTransform: 'uppercase' }}>Submitted</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: '#f59e0b' }}>{submittedCount}</span>
              </div>

              <div className="funnel-stage" style={{ borderLeftColor: '#0369a1', borderLeftWidth: '2px' }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: '#0369a1', textTransform: 'uppercase' }}>Assigned</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: '#0369a1' }}>{assignedCount}</span>
              </div>

              <div className="funnel-stage" style={{ borderLeftColor: '#3b82f6', borderLeftWidth: '2px' }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: '#1d4ed8', textTransform: 'uppercase' }}>In Progress</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: '#3b82f6' }}>{inProgressCount}</span>
              </div>

              <div className="funnel-stage" style={{ borderLeftColor: '#ef4444', borderLeftWidth: '2px' }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: '#b91c1c', textTransform: 'uppercase' }}>Approved / Rej</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: 'var(--text-dark)' }}>
                  <span style={{ color: '#10b981' }}>{approvedCount}</span> / <span style={{ color: '#ef4444' }}>{rejectedCount}</span>
                </span>
              </div>

              <div className="funnel-stage" style={{ borderLeftColor: '#06b6d4', borderLeftWidth: '2px' }}>
                <span style={{ fontSize: '11px', fontWeight: 600, color: '#0f766e', textTransform: 'uppercase' }}>Completed</span>
                <span style={{ fontSize: '22px', fontWeight: 700, color: '#06b6d4' }}>{completedCount}</span>
              </div>

            </div>
          </div>

          {/* 4. Recent Employee Submissions */}
          <div className="card" style={{ padding: '24px', backgroundColor: '#fff' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)' }}>Recent Employee Submissions</h3>
                <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>Latest verifications dispatched for screening.</p>
              </div>
              <button className="btn btn-outline" onClick={() => navigate('/hr/employees')} style={{ padding: '6px 12px', fontSize: '12px' }}>
                View Employee List <ChevronRight size={14} style={{ marginLeft: '4px' }} />
              </button>
            </div>

            <div style={{ overflowX: 'auto' }}>
              {recentSubmissions.length === 0 ? (
                <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-gray)' }}>No submitted verifications yet.</div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border-color)', backgroundColor: '#f8fafc' }}>
                      <th style={{ padding: '12px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>EMPLOYEE NAME</th>
                      <th style={{ padding: '12px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SUBMISSION DATE</th>
                      <th style={{ padding: '12px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>SERVICE TYPE</th>
                      <th style={{ padding: '12px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>STATUS</th>
                      <th style={{ padding: '12px 16px', fontSize: '11px', fontWeight: 600, color: 'var(--text-gray)' }}>ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentSubmissions.map((row) => (
                      <tr key={row.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ fontWeight: 600, fontSize: '14px' }}>{row.name}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{row.id}</div>
                        </td>
                        <td style={{ padding: '12px 16px', fontSize: '13px', color: 'var(--text-gray)' }}>
                          {row.submittedDate ? new Date(row.submittedDate).toLocaleDateString() : 'N/A'}
                        </td>
                        <td style={{ padding: '12px 16px', fontSize: '13px' }}>
                          {getServiceType(row)}
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <span className={`badge ${getStatusClass(row.status)}`}>{row.status.replace('-', ' ')}</span>
                        </td>
                        <td style={{ padding: '12px 16px' }}>
                          <button 
                            className="btn btn-outline" 
                            onClick={() => navigate('/hr/employees', { state: { viewEmployeeId: row.id } })}
                            style={{ padding: '4px 8px', fontSize: '11px' }}
                          >
                            <Eye size={12} style={{ marginRight: '4px' }} /> View
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

        </div>

        {/* Right Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* 1. Draft Summary Widget */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Layers size={16} color="var(--primary-blue)" /> Draft Summary
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', backgroundColor: 'var(--bg-hover)', borderRadius: '6px' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 500 }}>Total Drafts</span>
                <span style={{ fontSize: '16px', fontWeight: 700, color: 'var(--text-dark)' }}>{totalDrafts}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', backgroundColor: '#fef3c7', borderRadius: '6px' }}>
                <span style={{ fontSize: '13px', color: '#92400e', fontWeight: 500 }}>Awaiting Documents</span>
                <span style={{ fontSize: '16px', fontWeight: 700, color: '#d97706' }}>{draftsAwaiting}</span>
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', backgroundColor: '#dcfce7', borderRadius: '6px' }}>
                <span style={{ fontSize: '13px', color: '#166534', fontWeight: 500 }}>Ready For Submission</span>
                <span style={{ fontSize: '16px', fontWeight: 700, color: '#15803d' }}>{draftsReady}</span>
              </div>

              <button 
                className="btn btn-outline" 
                onClick={() => navigate('/hr/employees', { state: { showDraftsOnly: true } })}
                style={{ width: '100%', fontSize: '12px', padding: '8px', marginTop: '4px' }}
              >
                Go to Draft Workspace <ChevronRight size={14} style={{ marginLeft: '4px' }} />
              </button>

            </div>
          </div>

          {/* 2. Document Validation Summary */}
          <div className="card" style={{ padding: '20px', backgroundColor: '#fff' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <ShieldCheck size={16} color="#10b981" /> Document Health
            </h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '12px' }}>
              
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 4px', borderBottom: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--text-gray)' }}>
                  <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#94a3b8' }}></div>
                  Missing Documents
                </div>
                <span style={{ fontWeight: 700, color: 'var(--text-dark)', fontSize: '14px' }}>{missingDocs}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 4px', borderBottom: '1px solid var(--border-color)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--text-gray)' }}>
                  <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#ef4444' }}></div>
                  Rejected Documents
                </div>
                <span style={{ fontWeight: 700, color: '#dc2626', fontSize: '14px' }}>{rejectedDocs}</span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 4px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--text-gray)' }}>
                  <div style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#f59e0b' }}></div>
                  Re-upload Required
                </div>
                <span style={{ fontWeight: 700, color: '#d97706', fontSize: '14px' }}>{reuploadDocs}</span>
              </div>

            </div>
          </div>

        </div>

      </div>

      {/* Analytics Charts Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
        
        {/* Status Distribution */}
        <div className="card" style={{ padding: '24px', backgroundColor: '#fff', display: 'flex', flexDirection: 'column', minHeight: '380px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '4px' }}>Status Distribution</h3>
          <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '24px' }}>Summary of active verification stages.</p>
          
          {totalChartCount === 0 ? (
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-gray)' }}>
              No status data available
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '32px', flex: 1 }}>
              
              {/* Donut Chart SVG */}
              <div style={{ position: 'relative', width: '180px', height: '180px' }}>
                <svg viewBox="0 0 36 36" style={{ transform: 'rotate(-90deg)', width: '100%', height: '100%' }}>
                  <circle cx="18" cy="18" r="15.915" fill="transparent" stroke="#f1f5f9" strokeWidth="4.2" />
                  
                  {donutSegments.map((seg, idx) => (
                    <circle
                      key={idx}
                      cx="18"
                      cy="18"
                      r="15.915"
                      fill="transparent"
                      stroke={seg.color}
                      strokeWidth={hoveredSegment === idx ? '5.2' : '4.2'}
                      strokeDasharray={seg.strokeDash}
                      strokeDashoffset={seg.strokeOffset}
                      strokeLinecap="round"
                      style={{ transition: 'stroke-width 0.3s ease, filter 0.3s ease', cursor: 'pointer' }}
                      onMouseEnter={() => setHoveredSegment(idx)}
                      onMouseLeave={() => setHoveredSegment(null)}
                      filter={hoveredSegment === idx ? 'drop-shadow(0px 2px 4px rgba(0,0,0,0.15))' : 'none'}
                    />
                  ))}
                </svg>
                <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', pointerEvents: 'none' }}>
                  <span style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)', lineHeight: 1 }}>
                    {hoveredSegment !== null ? donutSegments[hoveredSegment].count : totalChartCount}
                  </span>
                  <span style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px', fontWeight: 500 }}>
                    {hoveredSegment !== null ? donutSegments[hoveredSegment].label : 'Total Items'}
                  </span>
                </div>
              </div>

              {/* Legend Grid */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1 }}>
                {donutSegments.map((seg, idx) => (
                  <div 
                    key={idx} 
                    style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'space-between', 
                      padding: '6px 10px', 
                      borderRadius: '6px',
                      backgroundColor: hoveredSegment === idx ? 'var(--bg-hover)' : 'transparent',
                      transition: 'background-color 0.2s'
                    }}
                    onMouseEnter={() => setHoveredSegment(idx)}
                    onMouseLeave={() => setHoveredSegment(null)}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: seg.color }}></div>
                      <span style={{ fontSize: '13px', fontWeight: 500, color: hoveredSegment === idx ? 'var(--text-dark)' : 'var(--text-gray)' }}>{seg.label}</span>
                    </div>
                    <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-dark)' }}>{seg.count}</span>
                  </div>
                ))}
              </div>

            </div>
          )}
        </div>

        {/* Service-wise Breakdown */}
        <div className="card" style={{ padding: '24px', backgroundColor: '#fff', display: 'flex', flexDirection: 'column', minHeight: '380px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '4px' }}>Service Type Breakdown</h3>
          <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '24px' }}>Active verification requests categorized by package.</p>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px', justifyContent: 'center', flex: 1 }}>
            {serviceData.map((service, idx) => (
              <div key={idx} style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', fontWeight: 500 }}>
                  <span style={{ color: 'var(--text-dark)', fontWeight: 600 }}>{service.name}</span>
                  <span style={{ color: 'var(--text-gray)' }}>{service.count} Cases ({service.percentage}%)</span>
                </div>
                <div style={{ width: '100%', height: '10px', backgroundColor: '#f1f5f9', borderRadius: '5px', overflow: 'hidden' }}>
                  <div style={{ 
                    width: `${service.percentage}%`, 
                    height: '100%', 
                    backgroundImage: 'linear-gradient(90deg, var(--primary-blue), #3b82f6)', 
                    borderRadius: '5px',
                    transition: 'width 0.8s cubic-bezier(0.4, 0, 0.2, 1)'
                  }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Grid 2: Monthly Trends and Notification Snapshot */}
      <div style={{ display: 'grid', gridTemplateColumns: '8fr 4fr', gap: '24px', alignItems: 'start' }}>
        
        {/* Monthly Trends */}
        <div className="card" style={{ padding: '24px', backgroundColor: '#fff', display: 'flex', flexDirection: 'column', minHeight: '340px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '24px' }}>
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-dark)' }}>Monthly Trends</h3>
              <p style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '4px' }}>Submission volumes over the last 6 months.</p>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#10b981', fontSize: '13px', fontWeight: 600 }}>
              <TrendingUp size={16} />
              <span>+18.5% Growth</span>
            </div>
          </div>

          <div style={{ position: 'relative', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <svg viewBox="0 0 400 180" style={{ width: '100%', height: '150px' }}>
              <defs>
                <linearGradient id="barGrad2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--primary-blue)" stopOpacity="1" />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.4" />
                </linearGradient>
              </defs>

              <line x1="30" y1="20" x2="380" y2="20" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="30" y1="60" x2="380" y2="60" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="30" y1="100" x2="380" y2="100" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="30" y1="140" x2="380" y2="140" stroke="#e2e8f0" strokeWidth="1.5" />

              <text x="15" y="24" fill="var(--text-gray)" fontSize="10" textAnchor="end">15</text>
              <text x="15" y="64" fill="var(--text-gray)" fontSize="10" textAnchor="end">10</text>
              <text x="15" y="104" fill="var(--text-gray)" fontSize="10" textAnchor="end">5</text>
              <text x="15" y="144" fill="var(--text-gray)" fontSize="10" textAnchor="end">0</text>

              {[
                { month: 'Jan', value: 4, x: 50 },
                { month: 'Feb', value: 8, x: 105 },
                { month: 'Mar', value: 6, x: 160 },
                { month: 'Apr', value: 11, x: 215 },
                { month: 'May', value: 13, x: 270 },
                { month: 'Jun', value: totalEmployees + 10, x: 325 }
              ].map((bar, idx) => {
                const barHeight = (bar.value / 20) * 120;
                const y = 140 - barHeight;
                return (
                  <g key={idx}>
                    <rect
                      x={bar.x}
                      y={y}
                      width="16"
                      height={barHeight}
                      rx="3"
                      fill="url(#barGrad2)"
                      style={{ transition: 'all 0.3s ease' }}
                    />
                    <text x={bar.x + 8} y="158" fill="var(--text-gray)" fontSize="11" textAnchor="middle">{bar.month}</text>
                    <text x={bar.x + 8} y={y - 6} fill="var(--text-dark)" fontSize="10" fontWeight="bold" textAnchor="middle">{bar.value}</text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* 3. Notification Snapshot */}
        <div className="card" style={{ padding: '24px', backgroundColor: '#fff', display: 'flex', flexDirection: 'column', minHeight: '340px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h3 style={{ fontSize: '15px', fontWeight: 600, color: 'var(--text-dark)', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BellRing size={16} color="var(--primary-blue)" /> Alerts Snapshot
            </h3>
            {unreadNotifsCount > 0 && (
              <span style={{ fontSize: '11px', padding: '2px 8px', borderRadius: '10px', backgroundColor: '#fee2e2', color: '#dc2626', fontWeight: 700 }}>
                {unreadNotifsCount} New
              </span>
            )}
          </div>

          {/* Quick Category Summary Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
            <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '6px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <span style={{ fontSize: '10px', color: 'var(--text-gray)', fontWeight: 600 }}>Approvals</span>
              <span style={{ fontSize: '15px', fontWeight: 700, color: '#10b981', marginTop: '2px' }}>{approvalNotifsCount}</span>
            </div>
            <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '6px', border: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <span style={{ fontSize: '10px', color: 'var(--text-gray)', fontWeight: 600 }}>Rejections</span>
              <span style={{ fontSize: '15px', fontWeight: 700, color: '#ef4444', marginTop: '2px' }}>{rejectionNotifsCount}</span>
            </div>
          </div>

          {/* Notification feed stack */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', flex: 1 }}>
            {notificationFeed.length === 0 ? (
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-gray)', fontSize: '12px' }}>
                No notifications logged.
              </div>
            ) : (
              notificationFeed.map((notif) => (
                <div 
                  key={notif.id} 
                  style={{ 
                    display: 'flex', 
                    gap: '8px', 
                    padding: '8px', 
                    borderRadius: '6px', 
                    border: '1px solid var(--border-color)',
                    backgroundColor: notif.read ? 'transparent' : 'var(--primary-blue-light)',
                    fontSize: '12px'
                  }}
                >
                  <div style={{ marginTop: '2px' }}>
                    {notif.type === 'rejection' ? (
                      <AlertTriangle size={14} color="#dc2626" />
                    ) : notif.type === 'remarks' ? (
                      <MessageSquare size={14} color="var(--primary-blue)" />
                    ) : (
                      <FileCheck size={14} color="#10b981" />
                    )}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-dark)' }}>{notif.title}</div>
                    <div style={{ color: 'var(--text-gray)', marginTop: '2px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '180px' }}>
                      {notif.message}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <button 
            className="btn btn-outline" 
            onClick={() => navigate('/hr/notifications')}
            style={{ width: '100%', fontSize: '12px', padding: '8px', marginTop: '16px' }}
          >
            View All Notifications <ChevronRight size={14} style={{ marginLeft: '4px' }} />
          </button>
        </div>

      </div>

    </div>
  );
};
export default Dashboard;
