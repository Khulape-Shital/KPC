import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FileBarChart, Search, Filter, Download, Printer, Save, 
  Star, Clock, AlertTriangle, CheckCircle2, TrendingUp, 
  BarChart3, PieChart, Activity, ChevronDown, ChevronRight, Eye
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

const REPORT_CATEGORIES = [
  'Verification Summary',
  'Status Distribution',
  'Monthly Trends',
  'Service-wise Reports',
  'SLA Performance',
  'Rejected Cases Analysis'
];

export const Reports = () => {
  const navigate = useNavigate();
  const [employees, setEmployees] = useState([]);
  
  // States for Filters
  const [dateRange, setDateRange] = useState('30 Days');
  const [serviceType, setServiceType] = useState('All');
  const [employeeStatus, setEmployeeStatus] = useState('All');
  const [verificationType, setVerificationType] = useState('All');
  const [activeCategory, setActiveCategory] = useState('Verification Summary');

  // Saved Reports State
  const [savedReports, setSavedReports] = useState([
    { id: 1, name: 'Q1 Submission Summary', date: '2026-04-01', type: 'Verification Summary' },
    { id: 2, name: 'May Rejections Analysis', date: '2026-06-01', type: 'Rejected Cases Analysis' }
  ]);
  const [favorites, setFavorites] = useState([1]);

  useEffect(() => {
    // Fetch non-draft employees for accurate reporting
    setEmployees(mockDb.getEmployees().filter(e => e.status !== 'draft'));
  }, []);

  // Filtered Data based on active filters
  const filteredData = useMemo(() => {
    return employees.filter(emp => {
      // Date Range Filter logic (mocked simplistically for now)
      const submitDate = emp.submittedDate ? new Date(emp.submittedDate) : new Date(emp.createdDate);
      const now = new Date();
      const daysDiff = (now - submitDate) / (1000 * 60 * 60 * 24);
      
      let matchesDate = true;
      if (dateRange === 'Today') matchesDate = daysDiff <= 1;
      if (dateRange === '7 Days') matchesDate = daysDiff <= 7;
      if (dateRange === '30 Days') matchesDate = daysDiff <= 30;

      const empService = emp.services ? emp.services[0] : 'Identity Verification';
      const matchesService = serviceType === 'All' || empService === serviceType;
      const matchesStatus = employeeStatus === 'All' || emp.status === employeeStatus.toLowerCase().replace(' ', '-');
      
      return matchesDate && matchesService && matchesStatus;
    });
  }, [employees, dateRange, serviceType, employeeStatus]);

  // Derived Analytics Data
  const analytics = useMemo(() => {
    const total = filteredData.length;
    const completed = filteredData.filter(e => e.status === 'completed').length;
    const rejected = filteredData.filter(e => e.status === 'rejected').length;
    const approved = filteredData.filter(e => e.status === 'approved').length;
    
    // Approval vs Rejection Ratio
    const decisionTotal = approved + rejected;
    const approvalRatio = decisionTotal > 0 ? Math.round((approved / decisionTotal) * 100) : 0;
    
    // SLA Compliance (Completed cases within SLA)
    // simplistic mock: assume 85% compliance base, adjusted by rejected count
    const slaCompliance = total > 0 ? Math.max(0, 100 - (rejected / total * 20)) : 100;
    
    // Average Completion Time (Mocked 3-7 days)
    const avgTime = '4.2 Days';

    return { total, completed, rejected, approved, approvalRatio, slaCompliance, avgTime };
  }, [filteredData]);

  const handleExport = (type) => {
    if (filteredData.length === 0) return;
    // In a real app, this would trigger actual generation logic
    if (type === 'print') {
      window.print();
    } else {
      alert(`Exporting ${activeCategory} report as ${type}...`);
    }
  };

  const handleSaveReport = () => {
    const newReport = {
      id: Date.now(),
      name: `Custom ${activeCategory} - ${new Date().toLocaleDateString()}`,
      date: new Date().toISOString().split('T')[0],
      type: activeCategory
    };
    setSavedReports([newReport, ...savedReports]);
    alert('Report configuration saved.');
  };

  const toggleFavorite = (id) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(fId => fId !== id));
    } else {
      setFavorites([...favorites, id]);
    }
  };

  return (
    <div className="page-container" style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '24px', minHeight: '100vh' }}>
      
      {/* Header & Export Actions */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }} className="hide-on-print">
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '12px' }}>
            <FileBarChart size={28} color="var(--primary-blue)" />
            Analytics & Reports
          </h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '8px', fontSize: '15px' }}>
            Generate, analyze, and export verification pipeline metrics.
          </p>
        </div>
        
        <div style={{ display: 'flex', gap: '12px' }}>
          <button onClick={handleSaveReport} className="btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Save size={18} /> Save Report
          </button>
          <div style={{ display: 'flex', background: 'var(--bg-secondary)', borderRadius: '6px', border: '1px solid var(--border-color)', overflow: 'hidden' }}>
            <button onClick={() => handleExport('csv')} style={{ padding: '8px 16px', border: 'none', background: 'transparent', borderRight: '1px solid var(--border-color)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600, color: 'var(--text-secondary)' }}>
              CSV
            </button>
            <button onClick={() => handleExport('pdf')} style={{ padding: '8px 16px', border: 'none', background: 'transparent', borderRight: '1px solid var(--border-color)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600, color: 'var(--text-secondary)' }}>
              PDF
            </button>
            <button onClick={() => handleExport('print')} style={{ padding: '8px 16px', border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600, color: 'var(--text-secondary)' }}>
              <Printer size={16} /> Print
            </button>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '24px', flex: 1, alignItems: 'flex-start' }}>
        
        {/* Left Sidebar: Controls & Saved Reports */}
        <div style={{ width: '300px', display: 'flex', flexDirection: 'column', gap: '24px' }} className="hide-on-print">
          
          {/* Filters Panel */}
          <div className="card" style={{ padding: '20px' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Filter size={16} /> Report Filters
            </h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '6px' }}>Date Range</label>
                <select className="select-input" value={dateRange} onChange={e => setDateRange(e.target.value)} style={{ width: '100%' }}>
                  <option value="Today">Today</option>
                  <option value="7 Days">Last 7 Days</option>
                  <option value="30 Days">Last 30 Days</option>
                  <option value="Custom">Custom Range...</option>
                </select>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '6px' }}>Service Type</label>
                <select className="select-input" value={serviceType} onChange={e => setServiceType(e.target.value)} style={{ width: '100%' }}>
                  <option value="All">All Services</option>
                  <option value="Identity Verification">Identity Verification</option>
                  <option value="Address Verification">Address Verification</option>
                  <option value="Background Check">Background Check</option>
                </select>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', marginBottom: '6px' }}>Employee Status</label>
                <select className="select-input" value={employeeStatus} onChange={e => setEmployeeStatus(e.target.value)} style={{ width: '100%' }}>
                  <option value="All">All Statuses</option>
                  <option value="Submitted">Submitted</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Completed">Completed</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>
          </div>

          {/* Categories */}
          <div className="card" style={{ padding: '16px' }}>
            <h3 style={{ fontSize: '12px', textTransform: 'uppercase', color: 'var(--text-light)', fontWeight: 700, letterSpacing: '1px', marginBottom: '12px', paddingLeft: '8px' }}>Report Types</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              {REPORT_CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  style={{
                    padding: '10px 12px',
                    textAlign: 'left',
                    background: activeCategory === cat ? 'var(--bg-secondary)' : 'transparent',
                    border: 'none',
                    borderRadius: '8px',
                    color: activeCategory === cat ? 'var(--primary-blue)' : 'var(--text-secondary)',
                    fontWeight: activeCategory === cat ? 600 : 500,
                    cursor: 'pointer',
                    fontSize: '14px',
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  {cat}
                  {activeCategory === cat && <ChevronRight size={16} />}
                </button>
              ))}
            </div>
          </div>

          {/* Saved & Favorites */}
          <div className="card" style={{ padding: '20px' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 700, color: 'var(--text-dark)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Star size={16} color="#f59e0b" /> Saved Reports
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {savedReports.map(report => (
                <div key={report.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px', background: 'var(--bg-secondary)', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
                  <div>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)', marginBottom: '4px' }}>{report.name}</div>
                    <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{report.date}</div>
                  </div>
                  <button 
                    onClick={() => toggleFavorite(report.id)}
                    style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: favorites.includes(report.id) ? '#f59e0b' : 'var(--text-light)' }}
                  >
                    <Star size={16} fill={favorites.includes(report.id) ? '#f59e0b' : 'none'} />
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Main Report View Area */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* Print Header Logo (only visible during print) */}
          <div className="print-only-header" style={{ display: 'none', alignItems: 'center', gap: '12px', marginBottom: '24px', borderBottom: '2px solid #000', paddingBottom: '16px' }}>
             <h2 style={{ margin: 0, fontSize: '24px' }}>KPC Verification Enterprise</h2>
             <span style={{ fontSize: '14px', color: '#666', marginLeft: 'auto' }}>Generated: {new Date().toLocaleString()}</span>
          </div>

          <style>{`
            @media print {
              .hide-on-print { display: none !important; }
              .print-only-header { display: flex !important; }
              .page-container { padding: 0 !important; margin: 0 !important; }
              .card { box-shadow: none !important; border: 1px solid #ccc !important; }
              body { background: #fff !important; }
            }
          `}</style>

          {/* High-Level Analytics Row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
            <div className="card" style={{ padding: '20px', borderTop: '4px solid var(--primary-blue)' }}>
              <div style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}><Activity size={16} /> Total Processed</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)' }}>{analytics.total}</div>
            </div>
            <div className="card" style={{ padding: '20px', borderTop: '4px solid #10b981' }}>
              <div style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}><CheckCircle2 size={16} /> Approval Ratio</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)' }}>{analytics.approvalRatio}%</div>
            </div>
            <div className="card" style={{ padding: '20px', borderTop: '4px solid #8b5cf6' }}>
              <div style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}><TrendingUp size={16} /> SLA Compliance</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)' }}>{analytics.slaCompliance.toFixed(1)}%</div>
            </div>
            <div className="card" style={{ padding: '20px', borderTop: '4px solid #f59e0b' }}>
              <div style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}><Clock size={16} /> Avg Turnaround</div>
              <div style={{ fontSize: '28px', fontWeight: 700, color: 'var(--text-dark)' }}>{analytics.avgTime}</div>
            </div>
          </div>

          {/* Detailed Report Content */}
          <div className="card" style={{ flex: 1, padding: '24px', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
              <div>
                <h2 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)' }}>{activeCategory}</h2>
                <p style={{ fontSize: '13px', color: 'var(--text-gray)', marginTop: '4px' }}>Showing {filteredData.length} records matching current filters.</p>
              </div>
            </div>

            {filteredData.length === 0 ? (
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--text-light)', border: '2px dashed var(--border-color)', borderRadius: '12px' }}>
                <FileBarChart size={48} style={{ opacity: 0.2, marginBottom: '16px' }} />
                <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-secondary)' }}>No Data Available</h3>
                <p style={{ marginTop: '8px', fontSize: '14px' }}>Try adjusting your date range or filters to see results.</p>
              </div>
            ) : (
              <div style={{ overflow: 'auto', flex: 1 }}>
                <table className="data-table" style={{ width: '100%', minWidth: '800px' }}>
                  <thead>
                    <tr>
                      <th>Employee Info</th>
                      <th>Submission Date</th>
                      <th>Service Details</th>
                      <th>Status</th>
                      <th>SLA Status</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredData.map(row => {
                      const slaDays = Math.floor((new Date() - new Date(row.submittedDate || row.createdDate)) / (1000 * 60 * 60 * 24));
                      const isBreached = slaDays > 7 && !['completed', 'approved', 'rejected'].includes(row.status);
                      const service = row.services ? row.services[0] : 'Identity Verification';

                      return (
                        <tr key={row.id} className="table-row-hover">
                          <td>
                            <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{row.name}</div>
                            <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>{row.id}</div>
                          </td>
                          <td>
                            <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                              {row.submittedDate ? new Date(row.submittedDate).toLocaleDateString() : 'N/A'}
                            </span>
                          </td>
                          <td>
                            <span style={{ fontSize: '13px', color: 'var(--text-primary)' }}>{service}</span>
                          </td>
                          <td>
                            <span className="badge" style={{ 
                              background: row.status === 'completed' ? '#dcfce7' : row.status === 'rejected' ? '#fee2e2' : 'var(--bg-secondary)',
                              color: row.status === 'completed' ? '#166534' : row.status === 'rejected' ? '#dc2626' : 'var(--text-primary)',
                              border: '1px solid var(--border-color)'
                            }}>
                              {row.status.replace('-', ' ')}
                            </span>
                          </td>
                          <td>
                            {isBreached ? (
                              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#ef4444', fontWeight: 600 }}>
                                <AlertTriangle size={14} /> Breached
                              </span>
                            ) : (
                              <span style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#10b981', fontWeight: 600 }}>
                                <CheckCircle2 size={14} /> Compliant
                              </span>
                            )}
                          </td>
                          <td style={{ textAlign: 'right', display: 'flex', gap: '8px', justifyContent: 'flex-end' }} className="hide-on-print">
                            <button onClick={() => navigate(`/hr/employees/${row.id}`)} className="btn-secondary" style={{ padding: '6px', fontSize: '12px' }} title="Open Employee Details">
                              <Eye size={14} />
                            </button>
                            <button onClick={() => navigate(`/hr/tracking`)} className="btn-secondary" style={{ padding: '6px', fontSize: '12px' }} title="Open Timeline">
                              <Clock size={14} />
                            </button>
                            {row.status === 'completed' && (
                              <button onClick={() => window.print()} className="btn-primary" style={{ padding: '6px', fontSize: '12px' }} title="Download Report">
                                <Download size={14} />
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
