import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Search, Calendar, Filter, Download, Plus, 
  Trash2, Send, CheckSquare, Eye, Edit3, X, 
  AlertTriangle, FileText, CheckCircle2, RefreshCw, FileSpreadsheet,
  Clock, Check, User, HelpCircle, FileCheck, ShieldAlert, AlertCircle
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

const SERVICE_TYPES = [
  { id: 'All', label: 'All Services' },
  { id: 'Identity Verification', label: 'Identity Verification' },
  { id: 'Background Verification', label: 'Background Verification' },
  { id: 'Address Verification', label: 'Address Verification' },
  { id: 'Police Verification', label: 'Police Verification' }
];

export const EmployeeList = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [employees, setEmployees] = useState([]);
  
  // Filtering states
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterService, setFilterService] = useState('All');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentTab, setCurrentTab] = useState('all'); // all, active, drafts

  // Smart Filter States
  const [filterRejectedShortcut, setFilterRejectedShortcut] = useState(false);
  const [filterPendingAction, setFilterPendingAction] = useState(false);

  // Selection states
  const [selectedRows, setSelectedRows] = useState([]);
  const [quickViewEmployee, setQuickViewEmployee] = useState(null);

  useEffect(() => {
    mockDb.init();
    loadEmployees();

    // Read navigation state parameters (e.g. from Dashboard Quick Actions)
    if (location.state) {
      if (location.state.filterStatus) {
        setFilterStatus(location.state.filterStatus);
        if (location.state.filterStatus === 'Rejected') {
          setFilterRejectedShortcut(true);
        }
        if (['Submitted', 'In Progress', 'Approved', 'Rejected', 'Completed'].includes(location.state.filterStatus)) {
          setCurrentTab('active');
        }
      }
      if (location.state.showDraftsOnly) {
        setCurrentTab('drafts');
        setFilterStatus('All');
      }
      if (location.state.viewEmployeeId) {
        const emp = mockDb.getEmployeeById(location.state.viewEmployeeId);
        if (emp) setQuickViewEmployee(emp);
      }
    }
  }, [location.state]);

  const loadEmployees = () => {
    setEmployees(mockDb.getEmployees());
  };

  // Helper: map internal state code to clean labels
  const getStatusLabel = (status) => {
    switch (status) {
      case 'draft': return 'Draft';
      case 'submitted': return 'Submitted';
      case 'assigned': return 'Assigned';
      case 'call-pending': return 'Call Pending';
      case 'otp-received': return 'OTP Received';
      case 'in-progress': return 'In Progress';
      case 'approved': return 'Approved';
      case 'rejected': return 'Rejected';
      case 'completed': return 'Completed';
      default: return status;
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case 'draft': return 'badge-draft';
      case 'submitted': return 'badge-submitted';
      case 'assigned': return 'badge-assigned';
      case 'call-pending': return 'badge-call-pending';
      case 'otp-received': return 'badge-otp-received';
      case 'in-progress': return 'badge-in-progress';
      case 'approved': return 'badge-approved';
      case 'rejected': return 'badge-rejected';
      case 'completed': return 'badge-completed';
      default: return '';
    }
  };

  const getServiceType = (emp) => {
    if (emp.id === 'EMP-90421') return 'Background Verification';
    if (emp.id === 'EMP-90422') return 'Background Verification';
    if (emp.id === 'EMP-90423') return 'Address Verification';
    if (emp.id === 'EMP-90424') return 'Identity Verification';
    return 'Identity Verification';
  };

  // 1. Document Completeness Helper
  const getDocCompleteness = (emp) => {
    const totalDocs = 6;
    const uploadedDocs = emp.documents ? emp.documents.length : 0;
    
    // Check if any uploaded document is rejected or re-upload required
    const hasRejected = emp.documents ? emp.documents.some(d => d.status === 'Rejected') : false;
    const hasReupload = emp.documents ? emp.documents.some(d => d.status === 'Re-upload Required') : false;
    
    // Check if mandatory Aadhaar & PAN are missing
    const docTypes = emp.documents ? emp.documents.map(d => d.type) : [];
    const missingMandatory = !docTypes.includes('Aadhaar Card') || !docTypes.includes('PAN Card');

    let state = 'Complete';
    let color = '#10b981'; // Green
    
    if (hasRejected || hasReupload) {
      state = 'Re-upload Required';
      color = '#ef4444'; // Red
    } else if (missingMandatory || uploadedDocs < 2) {
      state = 'Missing Documents';
      color = '#f59e0b'; // Amber
    }

    return {
      text: `${uploadedDocs}/${totalDocs} Uploaded`,
      state,
      color
    };
  };

  // 3. Last Activity Helper
  const getLastActivity = (emp) => {
    if (emp.timeline && emp.timeline.length > 0) {
      const last = emp.timeline[emp.timeline.length - 1];
      return {
        action: last.event,
        date: new Date(last.date).toLocaleDateString()
      };
    }
    return {
      action: 'Form Created',
      date: new Date(emp.createdDate).toLocaleDateString()
    };
  };

  // Apply filters
  const filteredEmployees = employees.filter(emp => {
    // 1. Search Query
    const query = search.toLowerCase();
    const matchSearch = emp.name.toLowerCase().includes(query) || emp.id.toLowerCase().includes(query) || (emp.contactNumber && emp.contactNumber.includes(query));

    // 2. Tab selection (all, active, drafts)
    let matchTab = true;
    if (currentTab === 'active') matchTab = emp.status !== 'draft';
    if (currentTab === 'drafts') matchTab = emp.status === 'draft';

    // 3. Rejected Shortcut Filter
    if (filterRejectedShortcut && emp.status !== 'rejected') return false;

    // 4. Pending My Action Smart Filter
    if (filterPendingAction) {
      const docsCheck = getDocCompleteness(emp);
      const isPending = emp.status === 'draft' || emp.status === 'rejected' || docsCheck.state === 'Re-upload Required' || docsCheck.state === 'Missing Documents';
      if (!isPending) return false;
    }

    // 5. Status filter (ignored if Rejected Shortcut is selected)
    let matchStatus = true;
    if (!filterRejectedShortcut && filterStatus !== 'All') {
      if (filterStatus === 'In Progress') {
        matchStatus = ['assigned', 'call-pending', 'otp-received', 'in-progress'].includes(emp.status);
      } else {
        matchStatus = emp.status === filterStatus.toLowerCase();
      }
    }

    // 6. Service filter
    let matchService = true;
    if (filterService !== 'All') {
      matchService = getServiceType(emp) === filterService;
    }

    // 7. Date filter
    let matchDate = true;
    const itemDate = new Date(emp.submittedDate || emp.createdDate);
    if (startDate) {
      matchDate = matchDate && itemDate >= new Date(startDate);
    }
    if (endDate) {
      const endLimit = new Date(endDate);
      endLimit.setHours(23, 59, 59, 999);
      matchDate = matchDate && itemDate <= endLimit;
    }

    return matchSearch && matchTab && matchStatus && matchService && matchDate;
  });

  // Checkbox interactions
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setSelectedRows(filteredEmployees.map(emp => emp.id));
    } else {
      setSelectedRows([]);
    }
  };

  const handleSelectRow = (id) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter(r => r !== id));
    } else {
      setSelectedRows([...selectedRows, id]);
    }
  };

  // Bulk Actions
  const handleBulkSubmit = () => {
    const selectedDrafts = employees.filter(emp => selectedRows.includes(emp.id) && emp.status === 'draft');
    
    if (selectedDrafts.length === 0) {
      alert('No selected drafts are available to submit.');
      return;
    }

    const incompleteDrafts = selectedDrafts.filter(d => {
      const comp = getDocCompleteness(d);
      return comp.state === 'Missing Documents' || comp.state === 'Re-upload Required';
    });

    if (incompleteDrafts.length > 0) {
      alert(`Cannot submit. The following drafts have missing/rejected documents: ${incompleteDrafts.map(i => i.name).join(', ')}`);
      return;
    }

    const updated = employees.map(emp => {
      if (selectedRows.includes(emp.id) && emp.status === 'draft') {
        const now = new Date().toISOString();
        return {
          ...emp,
          status: 'submitted',
          submittedDate: now,
          timeline: [
            ...emp.timeline,
            { event: 'Form Submitted', user: 'Client HR', date: now }
          ],
          audit: [
            ...emp.audit,
            { user: 'Client HR', action: 'Form Submitted (Bulk)', date: now }
          ]
        };
      }
      return emp;
    });

    mockDb.saveEmployees(updated);
    loadEmployees();
    setSelectedRows([]);
    alert(`Successfully submitted ${selectedDrafts.length} verifications!`);
  };

  const handleBulkDelete = () => {
    const selectedDrafts = employees.filter(emp => selectedRows.includes(emp.id) && emp.status === 'draft');
    
    if (selectedDrafts.length === 0) {
      alert('Only drafts can be deleted.');
      return;
    }

    if (window.confirm(`Are you sure you want to delete the selected ${selectedDrafts.length} drafts?`)) {
      const updated = employees.filter(emp => !(selectedRows.includes(emp.id) && emp.status === 'draft'));
      mockDb.saveEmployees(updated);
      loadEmployees();
      setSelectedRows([]);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (filteredEmployees.length === 0) {
      alert('No data available to export.');
      return;
    }

    let csvContent = 'ID,Name,DOB,Contact,Priority,Status,Service,Completeness,Last Action,Last Action Date\n';
    filteredEmployees.forEach(emp => {
      const comp = getDocCompleteness(emp);
      const act = getLastActivity(emp);
      csvContent += `"${emp.id}","${emp.name}","${emp.dob}","${emp.contactNumber}","${emp.priority}","${getStatusLabel(emp.status)}","${getServiceType(emp)}","${comp.text} (${comp.state})","${act.action}","${act.date}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `kpc_employees_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleClearFilters = () => {
    setSearch('');
    setFilterStatus('All');
    setFilterService('All');
    setStartDate('');
    setEndDate('');
    setCurrentTab('all');
    setFilterRejectedShortcut(false);
    setFilterPendingAction(false);
  };

  return (
    <div className="employee-list-container" style={{ display: 'flex', flexDirection: 'column', gap: '24px', animation: 'fadeIn 0.5s ease-out' }}>
      
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .tab-btn {
          padding: 8px 16px;
          border-radius: var(--radius-md);
          font-weight: 500;
          font-size: 14px;
          color: var(--text-gray);
          transition: all 0.2s;
        }
        .tab-btn:hover {
          color: var(--text-dark);
          background-color: var(--bg-hover);
        }
        .tab-btn.active {
          color: var(--primary-blue);
          background-color: var(--primary-blue-light);
          font-weight: 600;
        }
        .badge-draft { background-color: #f1f5f9; color: #475569; }
        .details-drawer {
          animation: slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
        @keyframes slideIn {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
        .filter-btn-shortcut {
          padding: 8px 16px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          border: 1px solid var(--border-color);
          background: #fff;
          color: var(--text-gray);
        }
        .filter-btn-shortcut.active {
          background-color: #fee2e2;
          color: #dc2626;
          border-color: #fca5a5;
        }
        .filter-btn-action.active {
          background-color: #fff7ed;
          color: #d97706;
          border-color: #fed7aa;
        }
        @media print {
          body { background-color: #fff; color: #000; }
          .sidebar, .top-header, .btn, .filter-section, .tabs-container, .bulk-actions-bar, .actions-column {
            display: none !important;
          }
          .main-wrapper, .main-content, .employee-list-container {
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
          }
          .card { border: none !important; box-shadow: none !important; }
          table { border: 1px solid #000 !important; width: 100% !important; }
          th, td { padding: 8px !important; border-bottom: 1px solid #000 !important; }
        }
      `}</style>

      {/* Header Panel */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '26px', fontWeight: 700, color: 'var(--text-dark)' }}>Employee List</h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '4px' }}>Register employees and track their credentials verification status.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-outline" onClick={handleExportCSV}>
            <FileSpreadsheet size={16} style={{ marginRight: '8px' }} /> Export CSV
          </button>
          <button className="btn btn-outline" onClick={() => window.print()}>
            <Download size={16} style={{ marginRight: '8px' }} /> Export PDF
          </button>
          <button className="btn btn-primary" onClick={() => navigate('/hr/employees/create')}>
            <Plus size={16} style={{ marginRight: '8px' }} /> Quick Create
          </button>
        </div>
      </div>

      {/* Workspace Tabs & Smart Shortcuts */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div className="card tabs-container" style={{ padding: '6px', display: 'inline-flex', gap: '4px', backgroundColor: '#e2e8f0', borderRadius: '10px' }}>
          <button className={`tab-btn ${currentTab === 'all' ? 'active' : ''}`} onClick={() => { setCurrentTab('all'); setSelectedRows([]); }}>All Cases ({employees.length})</button>
          <button className={`tab-btn ${currentTab === 'active' ? 'active' : ''}`} onClick={() => { setCurrentTab('active'); setSelectedRows([]); }}>Active Checks ({employees.filter(e => e.status !== 'draft').length})</button>
          <button className={`tab-btn ${currentTab === 'drafts' ? 'active' : ''}`} onClick={() => { setCurrentTab('drafts'); setSelectedRows([]); }}>Draft Workspace ({employees.filter(e => e.status === 'draft').length})</button>
        </div>

        {/* 5. Rejected Cases Shortcut & 6. Pending Actions Smart Filter */}
        <div style={{ display: 'flex', gap: '8px' }}>
          <button 
            className={`filter-btn-shortcut ${filterRejectedShortcut ? 'active' : ''}`}
            onClick={() => {
              setFilterRejectedShortcut(!filterRejectedShortcut);
              if (!filterRejectedShortcut) setFilterPendingAction(false); // mutually exclusive helper
            }}
          >
            <ShieldAlert size={15} />
            Rejected Cases ({employees.filter(e => e.status === 'rejected').length})
          </button>

          <button 
            className={`filter-btn-shortcut filter-btn-action ${filterPendingAction ? 'active' : ''}`}
            onClick={() => {
              setFilterPendingAction(!filterPendingAction);
              if (!filterPendingAction) setFilterRejectedShortcut(false);
            }}
          >
            <AlertCircle size={15} />
            Pending My Action
          </button>
        </div>
      </div>

      {/* Filter Section */}
      <div className="card filter-section" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px', backgroundColor: '#fff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1.5fr', gap: '16px' }}>
          
          <div className="header-search" style={{ border: '1px solid var(--border-color)', margin: 0, width: '100%', backgroundColor: '#fff' }}>
            <Search size={18} color="var(--text-gray)" />
            <input 
              type="text" 
              placeholder="Search by ID, Name, or Contact..." 
              value={search} 
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            <select 
              value={filterStatus} 
              onChange={(e) => setFilterStatus(e.target.value)}
              disabled={filterRejectedShortcut}
              style={{ padding: '10px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '14px', width: '100%', color: 'var(--text-dark)', backgroundColor: filterRejectedShortcut ? '#f1f5f9' : '#fff' }}
            >
              <option value="All">All Statuses</option>
              {currentTab !== 'drafts' && (
                <>
                  <option value="Submitted">Submitted</option>
                  <option value="Assigned">Assigned</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Approved">Approved</option>
                  <option value="Rejected">Rejected</option>
                  <option value="Completed">Completed</option>
                </>
              )}
              {currentTab === 'drafts' && <option value="Draft">Draft</option>}
            </select>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
            <select 
              value={filterService} 
              onChange={(e) => setFilterService(e.target.value)}
              style={{ padding: '10px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '14px', width: '100%', color: 'var(--text-dark)' }}
            >
              {SERVICE_TYPES.map(svc => (
                <option key={svc.id} value={svc.id}>{svc.label}</option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <input 
              type="date" 
              value={startDate} 
              onChange={(e) => setStartDate(e.target.value)}
              style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '12px', width: '50%' }}
            />
            <span style={{ fontSize: '12px', color: 'var(--text-gray)' }}>to</span>
            <input 
              type="date" 
              value={endDate} 
              onChange={(e) => setEndDate(e.target.value)}
              style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)', fontSize: '12px', width: '50%' }}
            />
          </div>

        </div>

        {(search || filterStatus !== 'All' || filterService !== 'All' || startDate || endDate || filterRejectedShortcut || filterPendingAction) && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-gray)' }}>
              Showing <strong>{filteredEmployees.length}</strong> matching entries.
            </span>
            <button className="btn btn-outline" onClick={handleClearFilters} style={{ padding: '4px 8px', fontSize: '12px', color: '#dc2626', borderColor: '#fee2e2' }}>
              Clear Active Filters
            </button>
          </div>
        )}
      </div>

      {/* Bulk Actions Bar */}
      {selectedRows.length > 0 && (
        <div className="card bulk-actions-bar" style={{ padding: '16px 24px', backgroundColor: 'var(--primary-blue-light)', border: '1px solid var(--primary-blue)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderRadius: '12px' }}>
          <span style={{ color: 'var(--primary-blue)', fontWeight: 600, fontSize: '14px' }}>
            {selectedRows.length} Employee{selectedRows.length > 1 ? 's' : ''} Selected
          </span>
          <div style={{ display: 'flex', gap: '12px' }}>
            {currentTab !== 'active' && (
              <>
                <button className="btn btn-primary" onClick={handleBulkSubmit} style={{ padding: '6px 14px', fontSize: '12px' }}>
                  <Send size={14} style={{ marginRight: '6px' }} /> Bulk Submit verifications
                </button>
                <button className="btn btn-outline" onClick={handleBulkDelete} style={{ padding: '6px 14px', fontSize: '12px', borderColor: '#ef4444', color: '#dc2626', backgroundColor: '#fff' }}>
                  <Trash2 size={14} style={{ marginRight: '6px' }} /> Bulk Delete Drafts
                </button>
              </>
            )}
            <button className="btn btn-outline" onClick={() => setSelectedRows([])} style={{ padding: '6px 14px', fontSize: '12px', backgroundColor: '#fff' }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Main Employee Table */}
      <div className="card" style={{ overflow: 'hidden', backgroundColor: '#fff' }}>
        {filteredEmployees.length === 0 ? (
          <div style={{ padding: '64px', textAlign: 'center' }}>
            <FileText size={48} color="var(--text-light)" style={{ marginBottom: '16px', display: 'inline-block' }} />
            <h3 style={{ fontSize: '18px', marginBottom: '8px' }}>No Employees Found</h3>
            <p style={{ color: 'var(--text-gray)', marginBottom: '16px' }}>Try adjusting your search criteria, dates, or filter categories.</p>
            <button className="btn btn-outline" onClick={handleClearFilters}>Reset Filters</button>
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '16px' }} className="actions-column">
                  <input 
                    type="checkbox" 
                    onChange={handleSelectAll} 
                    checked={selectedRows.length === filteredEmployees.length && filteredEmployees.length > 0} 
                  />
                </th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>EMPLOYEE DETAILS</th>
                {/* 1. Document Completeness Indicator Column */}
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>DOCUMENTS</th>
                {/* 2. Verification Service Column */}
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>VERIFICATION SERVICE</th>
                {/* 3. Last Activity Column */}
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>LAST ACTIVITY</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>STATUS</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }} className="actions-column">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filteredEmployees.map((emp) => {
                const docStatus = getDocCompleteness(emp);
                const lastAct = getLastActivity(emp);
                return (
                  <tr key={emp.id} style={{ borderBottom: '1px solid var(--border-color)', backgroundColor: selectedRows.includes(emp.id) ? 'var(--bg-hover)' : 'transparent' }}>
                    <td style={{ padding: '16px' }} className="actions-column">
                      <input 
                        type="checkbox" 
                        checked={selectedRows.includes(emp.id)} 
                        onChange={() => handleSelectRow(emp.id)} 
                      />
                    </td>
                    <td style={{ padding: '16px' }}>
                      <div style={{ fontWeight: 600, fontSize: '14px', color: 'var(--text-dark)' }}>{emp.name}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px' }}>{emp.id}</div>
                    </td>
                    
                    {/* 1. Completeness Cell */}
                    <td style={{ padding: '16px' }}>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{docStatus.text}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: docStatus.color, marginTop: '2px', fontWeight: 600 }}>
                        <span style={{ display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', backgroundColor: docStatus.color }}></span>
                        {docStatus.state}
                      </div>
                    </td>

                    {/* 2. Service Cell */}
                    <td style={{ padding: '16px', fontSize: '13px', color: 'var(--text-dark)', fontWeight: 500 }}>
                      {getServiceType(emp)}
                    </td>

                    {/* 3. Last Activity Cell */}
                    <td style={{ padding: '16px' }}>
                      <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-dark)' }}>{lastAct.action}</div>
                      <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px' }}>{lastAct.date}</div>
                    </td>

                    <td style={{ padding: '16px' }}>
                      <span className={`badge ${getStatusClass(emp.status)}`}>{getStatusLabel(emp.status)}</span>
                    </td>
                    <td style={{ padding: '16px' }} className="actions-column">
                      <div style={{ display: 'flex', gap: '8px' }}>
                        {/* 4. Quick View Action */}
                        <button 
                          className="btn btn-outline" 
                          onClick={() => setQuickViewEmployee(emp)}
                          style={{ padding: '4px 8px', fontSize: '12px' }}
                        >
                          <Eye size={13} style={{ marginRight: '4px' }} /> Quick View
                        </button>
                        {emp.status === 'draft' && (
                          <button 
                            className="btn btn-outline" 
                            onClick={() => navigate(`/hr/employees/${emp.id}/edit`)}
                            style={{ padding: '4px 8px', fontSize: '12px', color: 'var(--primary-blue)' }}
                          >
                            <Edit3 size={13} style={{ marginRight: '4px' }} /> Resume
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* 4. Rich Quick View Side Drawer */}
      {quickViewEmployee && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 100, display: 'flex', justifyContent: 'flex-end' }}>
          <div className="details-drawer" style={{ width: '520px', backgroundColor: '#fff', height: '100%', boxShadow: '-4px 0 25px rgba(0,0,0,0.15)', display: 'flex', flexDirection: 'column' }}>
            
            {/* Drawer Header */}
            <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <h2 style={{ fontSize: '22px', fontWeight: 700, color: 'var(--text-dark)' }}>{quickViewEmployee.name}</h2>
                  <span className={`badge ${getStatusClass(quickViewEmployee.status)}`}>{getStatusLabel(quickViewEmployee.status)}</span>
                </div>
                <p style={{ color: 'var(--text-gray)', fontSize: '13px', marginTop: '2px' }}>Employee ID: {quickViewEmployee.id} • {getServiceType(quickViewEmployee)}</p>
              </div>
              <button 
                onClick={() => setQuickViewEmployee(null)} 
                style={{ padding: '8px', borderRadius: '50%', border: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
              >
                <X size={18} color="var(--text-gray)" />
              </button>
            </div>
            
            {/* Drawer Content */}
            <div style={{ padding: '24px', overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: '20px' }}>
              
              {/* Employee Information */}
              <div className="card" style={{ padding: '16px', backgroundColor: '#f8fafc' }}>
                <h4 style={{ fontSize: '12px', color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '12px', fontWeight: 700 }}>Employee Details</h4>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '13px', color: 'var(--text-dark)' }}>
                  <div><span style={{ color: 'var(--text-gray)' }}>DOB:</span> {quickViewEmployee.dob}</div>
                  <div><span style={{ color: 'var(--text-gray)' }}>Contact:</span> {quickViewEmployee.contactNumber || 'N/A'}</div>
                  <div><span style={{ color: 'var(--text-gray)' }}>Father's Name:</span> {quickViewEmployee.fatherName}</div>
                  <div><span style={{ color: 'var(--text-gray)' }}>Father's DOB:</span> {quickViewEmployee.fatherDob || 'N/A'}</div>
                  <div><span style={{ color: 'var(--text-gray)' }}>Mother's Name:</span> {quickViewEmployee.motherName}</div>
                  <div><span style={{ color: 'var(--text-gray)' }}>Mother's DOB:</span> {quickViewEmployee.motherDob || 'N/A'}</div>
                </div>
              </div>

              {/* Document Validation Grid */}
              <div className="card" style={{ padding: '16px' }}>
                <h4 style={{ fontSize: '12px', color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '12px', fontWeight: 700 }}>Documents & Validation Status</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {quickViewEmployee.documents && quickViewEmployee.documents.map((doc, idx) => {
                    let badgeColor = '#10b981'; // green
                    let bg = '#dcfce7';
                    if (doc.status === 'Rejected') { badgeColor = '#dc2626'; bg = '#fee2e2'; }
                    else if (doc.status === 'Re-upload Required') { badgeColor = '#d97706'; bg = '#fef3c7'; }
                    return (
                      <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', border: '1px solid var(--border-color)', borderRadius: '6px', fontSize: '13px' }}>
                        <div>
                          <div style={{ fontWeight: 600, color: 'var(--text-dark)' }}>{doc.type}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px' }}>{doc.name} ({doc.size}) • Quality: <strong>{doc.quality}</strong></div>
                        </div>
                        <span style={{ fontSize: '11px', fontWeight: 700, padding: '2px 8px', borderRadius: '4px', color: badgeColor, backgroundColor: bg }}>
                          {doc.status}
                        </span>
                      </div>
                    );
                  })}
                  {(!quickViewEmployee.documents || quickViewEmployee.documents.length === 0) && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '12px', border: '1px dashed #cbd5e1', borderRadius: '8px', color: 'var(--text-gray)', fontSize: '12px' }}>
                      <AlertTriangle size={16} color="#d97706" />
                      No documents uploaded. Aadhaar Card and PAN Card are mandatory.
                    </div>
                  )}
                </div>
              </div>

              {/* Timeline Summary */}
              <div className="card" style={{ padding: '16px' }}>
                <h4 style={{ fontSize: '12px', color: 'var(--text-gray)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '16px', fontWeight: 700 }}>Verification Timeline</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', position: 'relative', paddingLeft: '20px' }}>
                  
                  {/* Vertical Timeline bar */}
                  <div style={{ position: 'absolute', left: '6px', top: '8px', bottom: '8px', width: '2px', backgroundColor: '#e2e8f0' }}></div>
                  
                  {quickViewEmployee.timeline && quickViewEmployee.timeline.map((evt, idx) => (
                    <div key={idx} style={{ position: 'relative' }}>
                      {/* Dot icon indicator */}
                      <div style={{ 
                        position: 'absolute', 
                        left: '-20px', 
                        top: '4px', 
                        width: '10px', 
                        height: '10px', 
                        borderRadius: '50%', 
                        backgroundColor: idx === quickViewEmployee.timeline.length - 1 ? 'var(--primary-blue)' : '#cbd5e1',
                        border: '2px solid #fff',
                        boxShadow: '0 0 0 2px ' + (idx === quickViewEmployee.timeline.length - 1 ? 'var(--primary-blue-light)' : '#e2e8f0')
                      }}></div>
                      <div>
                        <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-dark)' }}>{evt.event}</div>
                        <div style={{ fontSize: '11px', color: 'var(--text-gray)', marginTop: '2px' }}>{new Date(evt.date).toLocaleString()} • by {evt.user}</div>
                        {evt.details && (
                          <div style={{ fontSize: '11px', color: 'var(--primary-blue)', marginTop: '4px', fontWeight: 500 }}>{evt.details}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Executive Remarks */}
              {quickViewEmployee.notes && (
                <div className="card" style={{ padding: '16px', borderLeft: '4px solid var(--primary-blue)', backgroundColor: 'var(--primary-blue-light)' }}>
                  <h4 style={{ fontSize: '12px', color: 'var(--primary-blue)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px', fontWeight: 700 }}>Executive Remarks</h4>
                  <p style={{ fontSize: '13px', color: 'var(--text-dark)', fontStyle: 'italic' }}>
                    "{quickViewEmployee.notes}"
                  </p>
                </div>
              )}

            </div>

            {/* Drawer Footer Actions */}
            <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border-color)', display: 'flex', gap: '12px', backgroundColor: '#f8fafc' }}>
              <button 
                className="btn btn-primary" 
                onClick={() => {
                  setQuickViewEmployee(null);
                  navigate(`/hr/employees/${quickViewEmployee.id}`);
                }}
                style={{ flex: 1 }}
              >
                Go to Complete Details Screen
              </button>
              {quickViewEmployee.status === 'draft' && (
                <button 
                  className="btn btn-outline" 
                  onClick={() => {
                    setQuickViewEmployee(null);
                    navigate(`/hr/employees/${quickViewEmployee.id}/edit`);
                  }}
                  style={{ color: 'var(--primary-blue)', backgroundColor: '#fff' }}
                >
                  Resume Draft
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
export default EmployeeList;
