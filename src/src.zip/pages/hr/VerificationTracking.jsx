import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, Filter, KanbanSquare, Table as TableIcon, List, Clock, 
  AlertCircle, CheckCircle, Clock3, MessageSquare, AlertTriangle, User,
  Calendar, FileText, ChevronRight, Activity
} from 'lucide-react';
import { mockDb } from '../../utils/mockDb';

const TRACKING_COLUMNS = [
  { id: 'submitted', title: 'Submitted', color: '#6366f1' },
  { id: 'assigned', title: 'Assigned', color: '#8b5cf6' },
  { id: 'call-pending', title: 'Call Pending', color: '#f59e0b' },
  { id: 'otp-received', title: 'OTP Received', color: '#3b82f6' },
  { id: 'in-progress', title: 'Verification In Progress', color: '#0ea5e9' },
  { id: 'approved', title: 'Approved', color: '#10b981' },
  { id: 'rejected', title: 'Rejected', color: '#ef4444' },
  { id: 'completed', title: 'Completed', color: '#22c55e' }
];

export const VerificationTracking = () => {
  const navigate = useNavigate();
  const [view, setView] = useState('kanban'); // kanban, table, timeline
  const [employees, setEmployees] = useState([]);
  
  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [serviceFilter, setServiceFilter] = useState('all');
  const [execFilter, setExecFilter] = useState('all');

  useEffect(() => {
    // Only fetch non-draft employees
    const allEmps = mockDb.getEmployees().filter(e => e.status !== 'draft');
    setEmployees(allEmps);
  }, []);

  // Compute filtered employees
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchesSearch = emp.name.toLowerCase().includes(search.toLowerCase()) || 
                            emp.id.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || emp.status === statusFilter;
      // In a real app, serviceType would be an array on employee. For mock, we might derive it or mock it.
      // Assuming we just bypass service matching for now or match against a mock field.
      const matchesService = serviceFilter === 'all' || (emp.services && emp.services.includes(serviceFilter));
      
      const assignedExec = emp.timeline?.find(t => t.event === 'Executive Assigned')?.details || 'Unassigned';
      const matchesExec = execFilter === 'all' || assignedExec.includes(execFilter);

      return matchesSearch && matchesStatus && matchesService && matchesExec;
    });
  }, [employees, search, statusFilter, serviceFilter, execFilter]);

  // Compute Metrics
  const metrics = useMemo(() => {
    const total = filteredEmployees.length;
    const submitted = filteredEmployees.filter(e => e.status === 'submitted').length;
    const inProgress = filteredEmployees.filter(e => ['assigned', 'call-pending', 'otp-received', 'in-progress'].includes(e.status)).length;
    const approved = filteredEmployees.filter(e => e.status === 'approved').length;
    const rejected = filteredEmployees.filter(e => e.status === 'rejected').length;
    const completed = filteredEmployees.filter(e => e.status === 'completed').length;
    
    return { total, submitted, inProgress, approved, rejected, completed };
  }, [filteredEmployees]);

  // Compute Timeline Events
  const timelineEvents = useMemo(() => {
    let events = [];
    filteredEmployees.forEach(emp => {
      if (emp.timeline) {
        emp.timeline.forEach(t => {
          events.push({
            ...t,
            employeeId: emp.id,
            employeeName: emp.name,
            serviceType: emp.services ? emp.services[0] : 'Identity Verification'
          });
        });
      }
    });
    // Sort descending by date
    return events.sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [filteredEmployees]);

  // SLA Calculation Helper
  const getSLA = (emp) => {
    if (!emp.submittedDate) return { days: 0, status: 'Safe', remaining: 'N/A' };
    const submitDate = new Date(emp.submittedDate);
    const now = new Date();
    const daysSince = Math.floor((now - submitDate) / (1000 * 60 * 60 * 24));
    
    let status = 'On Track';
    let remaining = '3 Days';
    
    if (daysSince > 7) {
      status = 'SLA Breached';
      remaining = '0 Days';
    } else if (daysSince > 4) {
      status = 'Near SLA Limit';
      remaining = `${7 - daysSince} Days`;
    } else {
      remaining = `${7 - daysSince} Days`;
    }
    
    if (['completed', 'approved', 'rejected'].includes(emp.status)) {
      status = 'Resolved';
      remaining = 'N/A';
    }
    
    return { days: daysSince, status, remaining };
  };

  return (
    <div className="page-container" style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '24px', height: '100vh', overflow: 'hidden' }}>
      
      {/* Header & View Toggle */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 700, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Activity size={24} color="var(--primary-blue)" />
            Verification Tracking
          </h1>
          <p style={{ color: 'var(--text-gray)', marginTop: '4px', fontSize: '14px' }}>Real-time read-only monitoring workspace</p>
        </div>
        
        <div style={{ display: 'flex', background: 'var(--bg-secondary)', padding: '4px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          <button 
            onClick={() => setView('kanban')}
            style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: view === 'kanban' ? '#fff' : 'transparent', color: view === 'kanban' ? 'var(--primary-blue)' : 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: view === 'kanban' ? 600 : 500, cursor: 'pointer', boxShadow: view === 'kanban' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', transition: 'all 0.2s' }}
          >
            <KanbanSquare size={16} /> Kanban
          </button>
          <button 
            onClick={() => setView('table')}
            style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: view === 'table' ? '#fff' : 'transparent', color: view === 'table' ? 'var(--primary-blue)' : 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: view === 'table' ? 600 : 500, cursor: 'pointer', boxShadow: view === 'table' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', transition: 'all 0.2s' }}
          >
            <TableIcon size={16} /> Table
          </button>
          <button 
            onClick={() => setView('timeline')}
            style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: view === 'timeline' ? '#fff' : 'transparent', color: view === 'timeline' ? 'var(--primary-blue)' : 'var(--text-gray)', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: view === 'timeline' ? 600 : 500, cursor: 'pointer', boxShadow: view === 'timeline' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', transition: 'all 0.2s' }}
          >
            <List size={16} /> Timeline
          </button>
        </div>
      </div>

      {/* Summary Metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '16px' }}>
        {[
          { label: 'Total Cases', value: metrics.total, color: 'var(--text-primary)' },
          { label: 'Submitted', value: metrics.submitted, color: '#6366f1' },
          { label: 'In Progress', value: metrics.inProgress, color: '#0ea5e9' },
          { label: 'Approved', value: metrics.approved, color: '#10b981' },
          { label: 'Rejected', value: metrics.rejected, color: '#ef4444' },
          { label: 'Completed', value: metrics.completed, color: '#22c55e' }
        ].map((metric, idx) => (
          <div key={idx} className="card" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-gray)', fontWeight: 500 }}>{metric.label}</span>
            <span style={{ fontSize: '24px', fontWeight: 700, color: metric.color }}>{metric.value}</span>
          </div>
        ))}
      </div>

      {/* Smart Filters */}
      <div className="card" style={{ padding: '16px', display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
        <div className="input-group" style={{ flex: 1, minWidth: '250px', position: 'relative' }}>
          <Search size={18} style={{ position: 'absolute', left: '12px', top: '10px', color: '#94a3b8' }} />
          <input 
            type="text" 
            placeholder="Search by Employee Name or ID..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: '36px' }}
          />
        </div>
        
        <select className="select-input" value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ width: '180px' }}>
          <option value="all">All Statuses</option>
          {TRACKING_COLUMNS.map(col => <option key={col.id} value={col.id}>{col.title}</option>)}
        </select>
        
        <select className="select-input" value={serviceFilter} onChange={e => setServiceFilter(e.target.value)} style={{ width: '180px' }}>
          <option value="all">All Services</option>
          <option value="Identity Verification">Identity Verification</option>
          <option value="Address Verification">Address Verification</option>
          <option value="Background Check">Background Check</option>
          <option value="Police Verification">Police Verification</option>
        </select>

        <select className="select-input" value={execFilter} onChange={e => setExecFilter(e.target.value)} style={{ width: '180px' }}>
          <option value="all">All Executives</option>
          <option value="Amitabh S.">Amitabh S.</option>
          <option value="Sanjay V.">Sanjay V.</option>
          <option value="Unassigned">Unassigned</option>
        </select>
      </div>

      {/* Views Container */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        
        {/* KANBAN VIEW */}
        {view === 'kanban' && (
          <div style={{ flex: 1, display: 'flex', gap: '20px', overflowX: 'auto', paddingBottom: '16px' }}>
            {TRACKING_COLUMNS.map(column => {
              const columnEmps = filteredEmployees.filter(e => e.status === column.id);
              
              return (
                <div key={column.id} style={{ minWidth: '320px', width: '320px', display: 'flex', flexDirection: 'column', gap: '12px', background: 'var(--bg-secondary)', borderRadius: '12px', padding: '12px', border: '1px solid var(--border-color)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 4px', marginBottom: '4px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: column.color }} />
                      <h3 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)' }}>{column.title}</h3>
                    </div>
                    <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)', background: '#fff', padding: '2px 8px', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
                      {columnEmps.length}
                    </span>
                  </div>
                  
                  <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', paddingRight: '4px' }}>
                    {columnEmps.map(emp => {
                      const sla = getSLA(emp);
                      const assignedExec = emp.timeline?.find(t => t.event === 'Executive Assigned')?.details || 'Unassigned';
                      const hasRejectedDoc = emp.documents?.some(d => d.status === 'Rejected');
                      const service = emp.services ? emp.services[0] : 'Identity Verification';
                      const isCompleted = emp.status === 'completed';
                      
                      // Status Alerts
                      const recentlyUpdated = (new Date() - new Date(emp.timeline?.[emp.timeline.length-1]?.date || emp.createdDate)) < 86400000;
                      const isRecentlyApproved = emp.status === 'approved' && recentlyUpdated;
                      const isRecentlyRejected = emp.status === 'rejected' && recentlyUpdated;

                      return (
                        <div 
                          key={emp.id} 
                          className="card" 
                          style={{ padding: '16px', borderLeft: `4px solid ${column.color}`, display: 'flex', flexDirection: 'column' }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                            <div style={{ cursor: 'pointer' }} onClick={() => navigate(`/hr/employees/${emp.id}`)}>
                              <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-primary)', ':hover': { color: 'var(--primary-blue)' } }}>{emp.name}</div>
                              <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>{emp.id}</div>
                            </div>
                            <div style={{ display: 'flex', gap: '4px' }}>
                              {hasRejectedDoc && <span title="Re-upload Required" style={{ background: '#fef2f2', color: '#ef4444', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: 600 }}>Re-upload Required</span>}
                              {!hasRejectedDoc && isRecentlyApproved && <span style={{ background: '#f0fdf4', color: '#10b981', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: 600 }}>Recently Approved</span>}
                              {!hasRejectedDoc && isRecentlyRejected && <span style={{ background: '#fef2f2', color: '#ef4444', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: 600 }}>Recently Rejected</span>}
                              {!hasRejectedDoc && !isRecentlyApproved && !isRecentlyRejected && recentlyUpdated && <span style={{ background: '#eff6ff', color: '#3b82f6', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: 600 }}>New Update</span>}
                            </div>
                          </div>
                          
                          <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                            <FileText size={12} /> {service}
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#475569', marginBottom: '12px', background: 'var(--bg-secondary)', padding: '6px 8px', borderRadius: '6px' }}>
                            <User size={14} /> {assignedExec}
                          </div>
                          
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: sla.status === 'SLA Breached' ? '#ef4444' : sla.status === 'Near SLA Limit' ? '#f59e0b' : '#10b981', fontWeight: 600 }}>
                              <Clock3 size={12} /> 
                              {sla.status !== 'Resolved' ? `${sla.status} (${sla.remaining})` : 'Resolved'}
                            </div>
                            <div style={{ fontSize: '11px', color: '#94a3b8' }}>
                              Updated {new Date(emp.timeline?.[emp.timeline.length-1]?.date || emp.createdDate).toLocaleDateString()}
                            </div>
                          </div>
                          
                          {/* Card Actions */}
                          <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
                            <button onClick={() => navigate(`/hr/employees/${emp.id}`)} className="btn-secondary" style={{ flex: 1, padding: '6px', fontSize: '11px' }}>
                              View Details
                            </button>
                            {isCompleted && (
                              <button onClick={() => { window.print(); }} className="btn-primary" style={{ flex: 1, padding: '6px', fontSize: '11px', background: '#22c55e', borderColor: '#22c55e' }}>
                                Download Report
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    {columnEmps.length === 0 && (
                      <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text-light)', fontSize: '13px', border: '1px dashed var(--border-color)', borderRadius: '8px' }}>
                        No cases
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TABLE VIEW */}
        {view === 'table' && (
          <div className="card" style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
            <div style={{ overflow: 'auto', flex: 1 }}>
              <table className="data-table" style={{ width: '100%', minWidth: '900px' }}>
                <thead>
                  <tr>
                    <th>Employee Info</th>
                    <th>Service Type</th>
                    <th>Current Status</th>
                    <th>Assigned Exec</th>
                    <th>Submission Date</th>
                    <th>Last Activity</th>
                    <th style={{ textAlign: 'right' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map(emp => {
                    const assignedExec = emp.timeline?.find(t => t.event === 'Executive Assigned')?.details || 'Unassigned';
                    const lastTimeline = emp.timeline?.[emp.timeline.length - 1];
                    const service = emp.services ? emp.services[0] : 'Identity Verification';
                    const sla = getSLA(emp);
                    const col = TRACKING_COLUMNS.find(c => c.id === emp.status);

                    return (
                      <tr key={emp.id} className="table-row-hover" style={{ cursor: 'pointer' }} onClick={() => navigate(`/hr/employees/${emp.id}`)}>
                        <td>
                          <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{emp.name}</div>
                          <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginTop: '2px' }}>{emp.id}</div>
                        </td>
                        <td>
                          <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>{service}</span>
                        </td>
                        <td>
                          <span className="badge" style={{ background: `${col?.color}15`, color: col?.color, border: `1px solid ${col?.color}30` }}>
                            {col?.title || emp.status}
                          </span>
                          {sla.status !== 'Resolved' && (
                            <div style={{ fontSize: '11px', marginTop: '4px', color: sla.status === 'SLA Breached' ? '#ef4444' : sla.status === 'Near SLA Limit' ? '#f59e0b' : 'var(--text-gray)' }}>
                              SLA: {sla.status} ({sla.remaining})
                            </div>
                          )}
                        </td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' }}>
                            <User size={14} color="var(--text-light)" /> {assignedExec}
                          </div>
                        </td>
                        <td>
                          <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                            {emp.submittedDate ? new Date(emp.submittedDate).toLocaleDateString() : 'N/A'}
                          </div>
                        </td>
                        <td>
                          <div style={{ fontSize: '13px', color: 'var(--text-primary)' }}>{lastTimeline?.event || 'Created'}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-light)', marginTop: '2px' }}>
                            {new Date(lastTimeline?.date || emp.createdDate).toLocaleString()}
                          </div>
                        </td>
                        <td style={{ textAlign: 'right' }}>
                          <button className="btn-secondary" style={{ padding: '6px 12px', fontSize: '13px' }}>
                            View <ChevronRight size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredEmployees.length === 0 && (
                    <tr>
                      <td colSpan="7" style={{ textAlign: 'center', padding: '48px', color: 'var(--text-light)' }}>
                        No records found matching filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TIMELINE VIEW */}
        {view === 'timeline' && (
          <div className="card" style={{ flex: 1, overflowY: 'auto', padding: '32px' }}>
            <div style={{ maxWidth: '800px', margin: '0 auto' }}>
              {timelineEvents.length === 0 ? (
                <div style={{ textAlign: 'center', color: 'var(--text-light)', padding: '48px' }}>No activity history found.</div>
              ) : (
                <div style={{ position: 'relative', borderLeft: '2px solid var(--border-color)', marginLeft: '16px' }}>
                  {timelineEvents.map((tEvent, idx) => {
                    const isRejection = tEvent.event.toLowerCase().includes('reject');
                    const isCompletion = tEvent.event.toLowerCase().includes('complet');
                    const isCreation = tEvent.event.toLowerCase().includes('creat');
                    
                    let Icon = Activity;
                    let color = 'var(--primary-blue)';
                    let bg = 'rgba(59, 130, 246, 0.1)';
                    
                    if (isRejection) { Icon = AlertTriangle; color = '#ef4444'; bg = '#fef2f2'; }
                    else if (isCompletion) { Icon = CheckCircle; color = '#22c55e'; bg = '#f0fdf4'; }
                    else if (isCreation) { Icon = User; color = '#8b5cf6'; bg = '#f5f3ff'; }
                    
                    return (
                      <div key={idx} style={{ position: 'relative', paddingLeft: '32px', paddingBottom: idx === timelineEvents.length - 1 ? '0' : '32px' }}>
                        <div style={{ position: 'absolute', left: '-17px', top: '0', width: '32px', height: '32px', borderRadius: '50%', backgroundColor: bg, border: `2px solid ${color}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: color }}>
                          <Icon size={16} />
                        </div>
                        
                        <div 
                          className="card" 
                          onClick={() => navigate(`/hr/employees/${tEvent.employeeId}`)}
                          style={{ padding: '16px', cursor: 'pointer', transition: 'transform 0.2s', ':hover': { transform: 'translateX(4px)' } }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                            <div style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '15px' }}>
                              {tEvent.event} <span style={{ fontWeight: 400, color: 'var(--text-gray)' }}>for</span> {tEvent.employeeName}
                            </div>
                            <div style={{ fontSize: '12px', color: 'var(--text-light)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                              <Clock size={12} /> {new Date(tEvent.date).toLocaleString()}
                            </div>
                          </div>
                          
                          <div style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '12px' }}>
                            Actor: <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>{tEvent.user}</span>
                          </div>
                          
                          {tEvent.details && (
                            <div style={{ background: 'var(--bg-secondary)', padding: '12px', borderRadius: '8px', fontSize: '13px', color: 'var(--text-primary)', borderLeft: `3px solid ${color}` }}>
                              {tEvent.details}
                            </div>
                          )}
                          
                          <div style={{ display: 'flex', gap: '12px', marginTop: '12px', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div style={{ display: 'flex', gap: '12px' }}>
                              <span style={{ fontSize: '11px', background: 'var(--bg-primary)', padding: '4px 8px', borderRadius: '4px', border: '1px solid var(--border-color)', color: 'var(--text-gray)' }}>
                                ID: {tEvent.employeeId}
                              </span>
                              <span style={{ fontSize: '11px', background: 'var(--bg-primary)', padding: '4px 8px', borderRadius: '4px', border: '1px solid var(--border-color)', color: 'var(--text-gray)' }}>
                                Service: {tEvent.serviceType}
                              </span>
                            </div>
                            <button onClick={(e) => { e.stopPropagation(); navigate(`/hr/employees/${tEvent.employeeId}`); }} className="btn-secondary" style={{ padding: '4px 12px', fontSize: '11px' }}>
                              View Employee Details <ChevronRight size={12} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
