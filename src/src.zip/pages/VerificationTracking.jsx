import React, { useState } from 'react';
import { Search, Filter, Kanban, Table as TableIcon, Clock, AlertTriangle, Users, Edit2, Flag, X, FileText, History, Info, MessageSquare } from 'lucide-react';

const STATUSES = ['Submitted', 'Assigned', 'Call Pending', 'OTP Received', 'In Progress', 'Approved', 'Rejected', 'Completed'];

const MOCK_DATA = [
  { id: '#V-1021', employee: 'Rajiv Jhunjhunwala', company: 'TechCorp Solutions', client: 'TechCorp Retail', exec: 'Amitabh S.', service: 'Identity Verification', priority: 'Urgent', sla: '7+ Days', status: 'In Progress', escalated: true, escReason: 'Client urgently requesting update', escBy: 'Operations Manager', escDate: 'Oct 24, 2023', lastUpdate: '2h ago' },
  { id: '#V-1022', employee: 'Priya Kulkarni', company: 'Vertex Group', client: 'Vertex Finance', exec: 'Sanjay V.', service: 'Background Verification', priority: 'Medium', sla: '1-3 Days', status: 'Assigned', escalated: false, lastUpdate: '5h ago' },
  { id: '#V-1023', employee: 'Anish Sharma', company: 'Innovate Global', client: 'Innovate HR', exec: 'Unassigned', service: 'Address Verification', priority: 'Low', sla: 'Submitted Today', status: 'Submitted', escalated: false, lastUpdate: 'Just now' },
  { id: '#V-1024', employee: 'Sneha Patel', company: 'TechCorp Solutions', client: 'TechCorp IT', exec: 'Amitabh S.', service: 'Police Verification', priority: 'High', sla: '4-7 Days', status: 'Call Pending', escalated: false, lastUpdate: '1d ago' },
];

export const VerificationTracking = () => {
  const [view, setView] = useState('kanban'); 
  const [data, setData] = useState(MOCK_DATA);
  const [modalData, setModalData] = useState(null);
  
  // Filters
  const [search, setSearch] = useState('');
  const [filterCompany, setFilterCompany] = useState('All');
  const [filterClient, setFilterClient] = useState('All');
  const [filterService, setFilterService] = useState('All');
  const [filterPriority, setFilterPriority] = useState('All');
  const [filterSla, setFilterSla] = useState('All');
  const [filterEscalated, setFilterEscalated] = useState('All');

  const filteredData = data.filter(item => {
    return (item.employee.toLowerCase().includes(search.toLowerCase()) || item.id.toLowerCase().includes(search.toLowerCase())) &&
           (filterCompany === 'All' || item.company === filterCompany) &&
           (filterClient === 'All' || item.client === filterClient) &&
           (filterService === 'All' || item.service === filterService) &&
           (filterPriority === 'All' || item.priority === filterPriority) &&
           (filterSla === 'All' || item.sla === filterSla) &&
           (filterEscalated === 'All' || (filterEscalated === 'Yes' ? item.escalated : !item.escalated));
  });

  const getSlaStyle = (sla) => {
    switch(sla) {
      case '7+ Days': return { bg: '#fef2f2', color: '#991b1b', border: '#fecaca' };
      case '4-7 Days': return { bg: '#fff7ed', color: '#9a3412', border: '#fed7aa' };
      case '1-3 Days': return { bg: '#f0fdf4', color: '#166534', border: '#bbf7d0' };
      default: return { bg: '#f8fafc', color: '#475569', border: '#e2e8f0' };
    }
  };

  const activeCount = data.length;
  const safeCount = data.filter(d => d.sla === 'Submitted Today' || d.sla === '1-3 Days').length;
  const warningCount = data.filter(d => d.sla === '4-7 Days').length;
  const breachedCount = data.filter(d => d.sla === '7+ Days').length;
  const escalatedCount = data.filter(d => d.escalated).length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', height: '100%' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>Verification Tracking</h1>
          <p style={{ color: 'var(--text-gray)' }}>Command center for overseeing verification workflows, SLAs, and escalations.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Users size={16} /> Bulk Reassign</button>
          <button className="btn btn-outline" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Edit2 size={16} /> Bulk Status Update</button>
        </div>
      </div>

      {/* SLA Dashboard Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '16px' }}>
        <div className="card" style={{ padding: '16px', borderTop: '4px solid var(--primary-blue)' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>TOTAL ACTIVE</div>
          <div style={{ fontSize: '24px', fontWeight: 700 }}>{activeCount}</div>
        </div>
        <div className="card" style={{ padding: '16px', borderTop: '4px solid #166534' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>SLA SAFE</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#166534' }}>{safeCount}</div>
        </div>
        <div className="card" style={{ padding: '16px', borderTop: '4px solid #ea580c' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>SLA WARNING (4-7)</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#ea580c' }}>{warningCount}</div>
        </div>
        <div className="card" style={{ padding: '16px', borderTop: '4px solid #dc2626' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600 }}>SLA BREACHED (7+)</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#dc2626' }}>{breachedCount}</div>
        </div>
        <div className="card" style={{ padding: '16px', borderTop: '4px solid #991b1b', backgroundColor: '#fef2f2' }}>
          <div style={{ fontSize: '12px', color: '#991b1b', fontWeight: 600 }}>ESCALATED CASES</div>
          <div style={{ fontSize: '24px', fontWeight: 700, color: '#991b1b' }}>{escalatedCount}</div>
        </div>
      </div>

      {/* Control Bar (Filters & View Toggles) */}
      <div className="card" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', flex: 1 }}>
            <div className="header-search" style={{ width: '220px', border: '1px solid var(--border-color)', margin: 0, backgroundColor: '#fff' }}>
              <Search size={16} color="var(--text-gray)" />
              <input type="text" placeholder="Search ID or Name" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <option value="All">All Companies</option>
              <option value="TechCorp Solutions">TechCorp</option>
              <option value="Vertex Group">Vertex</option>
            </select>
            <select value={filterClient} onChange={(e) => setFilterClient(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <option value="All">All Client Accounts</option>
              <option value="TechCorp Retail">TechCorp Retail</option>
              <option value="TechCorp IT">TechCorp IT</option>
            </select>
            <select value={filterService} onChange={(e) => setFilterService(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <option value="All">All Services</option>
              <option value="Identity Verification">Identity</option>
              <option value="Background Verification">Background</option>
              <option value="Police Verification">Police</option>
              <option value="Address Verification">Address</option>
            </select>
          </div>
          
          <div style={{ display: 'flex', backgroundColor: 'var(--bg-surface)', padding: '4px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            <button onClick={() => setView('kanban')} style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', backgroundColor: view === 'kanban' ? '#fff' : 'transparent', boxShadow: view === 'kanban' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: view === 'kanban' ? 600 : 400 }}><Kanban size={16} /> Kanban</button>
            <button onClick={() => setView('table')} style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', backgroundColor: view === 'table' ? '#fff' : 'transparent', boxShadow: view === 'table' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: view === 'table' ? 600 : 400 }}><TableIcon size={16} /> Table</button>
            <button onClick={() => setView('timeline')} style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', backgroundColor: view === 'timeline' ? '#fff' : 'transparent', boxShadow: view === 'timeline' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: view === 'timeline' ? 600 : 400 }}><Clock size={16} /> Timeline</button>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <select value={filterPriority} onChange={(e) => setFilterPriority(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            <option value="All">All Priorities</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
          </select>
          <select value={filterSla} onChange={(e) => setFilterSla(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            <option value="All">All SLAs</option>
            <option value="Submitted Today">Submitted Today</option>
            <option value="1-3 Days">1-3 Days</option>
            <option value="4-7 Days">4-7 Days</option>
            <option value="7+ Days">7+ Days (Breach)</option>
          </select>
          <select value={filterEscalated} onChange={(e) => setFilterEscalated(e.target.value)} style={{ padding: '8px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            <option value="All">Escalation Status</option>
            <option value="Yes">Escalated Only</option>
            <option value="No">Non-Escalated</option>
          </select>
        </div>
      </div>

      {/* Main Content Area */}
      {view === 'kanban' && (
        <div style={{ display: 'flex', gap: '16px', overflowX: 'auto', paddingBottom: '16px', flex: 1 }}>
          {STATUSES.map(status => (
            <div key={status} style={{ minWidth: '320px', backgroundColor: 'var(--bg-surface)', borderRadius: '12px', display: 'flex', flexDirection: 'column', maxHeight: '100%' }}>
              <div style={{ padding: '16px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ fontWeight: 600 }}>{status}</div>
                <div style={{ fontSize: '12px', padding: '2px 8px', backgroundColor: '#e2e8f0', borderRadius: '12px', fontWeight: 600 }}>
                  {filteredData.filter(d => d.status === status).length}
                </div>
              </div>
              <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '12px', overflowY: 'auto', flex: 1 }}>
                {filteredData.filter(d => d.status === status).map(card => {
                  const slaStyle = getSlaStyle(card.sla);
                  return (
                    <div key={card.id} className="card" onClick={() => setModalData(card)} style={{ padding: '16px', border: card.escalated ? '1px solid #dc2626' : '1px solid var(--border-color)', cursor: 'pointer', position: 'relative' }}>
                      {card.escalated && (
                        <div style={{ position: 'absolute', top: '-8px', right: '-8px', backgroundColor: '#dc2626', color: '#fff', borderRadius: '50%', padding: '4px' }}>
                          <Flag size={12} />
                        </div>
                      )}
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span style={{ fontSize: '12px', fontWeight: 600, color: 'var(--text-gray)' }}>{card.id}</span>
                        <span style={{ fontSize: '11px', padding: '2px 6px', borderRadius: '4px', backgroundColor: slaStyle.bg, color: slaStyle.color, border: `1px solid ${slaStyle.border}`, fontWeight: 600 }}>{card.sla}</span>
                      </div>
                      <div style={{ fontWeight: 600, marginBottom: '4px', fontSize: '14px' }}>{card.employee}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)', marginBottom: '12px' }}>{card.company} • {card.client} • {card.service}</div>
                      
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '12px', borderTop: '1px solid var(--border-color)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <div className="avatar" style={{ width: '24px', height: '24px', fontSize: '10px' }}>{card.exec !== 'Unassigned' ? card.exec.substring(0, 2).toUpperCase() : '?'}</div>
                          <span style={{ fontSize: '12px', color: card.exec === 'Unassigned' ? '#dc2626' : 'var(--text-gray)', fontWeight: card.exec === 'Unassigned' ? 600 : 400 }}>{card.exec}</span>
                        </div>
                        <div style={{ fontSize: '11px', color: 'var(--text-gray)' }}>{card.lastUpdate}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {view === 'table' && (
        <div className="card" style={{ overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>VERIFICATION ID</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>EMPLOYEE & COMPANY</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>SERVICE</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>EXECUTIVE</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>STATUS</th>
                <th style={{ padding: '16px', fontSize: '12px', color: 'var(--text-gray)' }}>SLA AGING</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map(row => {
                const slaStyle = getSlaStyle(row.sla);
                return (
                  <tr key={row.id} onClick={() => setModalData(row)} style={{ borderBottom: '1px solid var(--border-color)', backgroundColor: row.escalated ? '#fef2f2' : 'transparent', cursor: 'pointer' }}>
                    <td style={{ padding: '16px', fontWeight: 600 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        {row.escalated && <Flag size={14} color="#dc2626" />} {row.id}
                      </div>
                    </td>
                    <td style={{ padding: '16px' }}>
                      <div style={{ fontWeight: 600 }}>{row.employee}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>{row.company} • {row.client}</div>
                    </td>
                    <td style={{ padding: '16px' }}>{row.service}</td>
                    <td style={{ padding: '16px' }}>{row.exec}</td>
                    <td style={{ padding: '16px' }}><span className={`badge badge-${row.status.toLowerCase().replace(' ', '-')}`}>{row.status}</span></td>
                    <td style={{ padding: '16px' }}>
                      <span style={{ fontSize: '12px', padding: '4px 8px', borderRadius: '4px', backgroundColor: slaStyle.bg, color: slaStyle.color, border: `1px solid ${slaStyle.border}`, fontWeight: 600 }}>{row.sla}</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Case Details Drawer */}
      {modalData && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 50, display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ width: '600px', backgroundColor: '#fff', height: '100%', boxShadow: '-4px 0 15px rgba(0,0,0,0.1)', display: 'flex', flexDirection: 'column' }}>
            
            <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <h2 style={{ fontSize: '20px', margin: 0 }}>{modalData.employee}</h2>
                  <span style={{ fontSize: '12px', padding: '2px 8px', borderRadius: '12px', border: `1px solid #000`, fontWeight: 600 }}>{modalData.priority} Priority</span>
                </div>
                <div style={{ color: 'var(--text-gray)', fontSize: '14px' }}>{modalData.id} • {modalData.company} ({modalData.client})</div>
              </div>
              <button onClick={() => setModalData(null)} style={{ padding: '8px' }}><X size={20} /></button>
            </div>

            <div style={{ padding: '24px', overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: '24px' }}>
              
              {modalData.escalated && (
                <div style={{ backgroundColor: '#fef2f2', border: '1px solid #fecaca', padding: '16px', borderRadius: '8px' }}>
                  <h3 style={{ fontSize: '14px', color: '#dc2626', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}><Flag size={16} /> Escalation Center</h3>
                  <div style={{ fontSize: '13px', color: '#991b1b', marginBottom: '8px' }}><strong>Reason:</strong> {modalData.escReason}</div>
                  <div style={{ fontSize: '12px', color: '#991b1b' }}>Escalated by {modalData.escBy} on {modalData.escDate}</div>
                </div>
              )}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="card" style={{ padding: '16px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px' }}>SLA AGING</div>
                  <div style={{ fontWeight: 600, color: getSlaStyle(modalData.sla).color }}>{modalData.sla}</div>
                </div>
                <div className="card" style={{ padding: '16px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--text-gray)', fontWeight: 600, marginBottom: '8px' }}>ASSIGNMENT</div>
                  <div style={{ fontWeight: 600, color: modalData.exec === 'Unassigned' ? '#dc2626' : 'inherit' }}>{modalData.exec}</div>
                </div>
              </div>

              <div className="card" style={{ padding: '16px' }}>
                <h3 style={{ fontSize: '14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}><Info size={16} color="var(--primary-blue)" /> Service Information</h3>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 500 }}>{modalData.service}</span>
                  <span className={`badge badge-${modalData.status.toLowerCase().replace(' ', '-')}`}>{modalData.status}</span>
                </div>
              </div>

              <div className="card" style={{ padding: '16px' }}>
                <h3 style={{ fontSize: '14px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}><History size={16} color="var(--primary-blue)" /> Audit Trail & Timeline</h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <div className="avatar" style={{ width: '32px', height: '32px', fontSize: '12px', backgroundColor: '#e2e8f0', color: '#475569' }}>SY</div>
                    <div>
                      <div style={{ fontSize: '14px', fontWeight: 600 }}>Status updated to {modalData.status}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-gray)' }}>System • {modalData.lastUpdate}</div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
      
    </div>
  );
};
