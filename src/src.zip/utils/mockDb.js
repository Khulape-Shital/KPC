// Mock Database for KPC Verification Management System

const INITIAL_USERS = [
  { id: 'U-001', username: 'admin', password: 'admin@123', role: 'admin', name: 'System Admin' },
  { id: 'U-002', username: 'operation', password: 'Ops@123', role: 'ops', name: 'Operations Manager' }
];

export const mockDb = {
  init: () => {
    if (!localStorage.getItem('kpc_users')) {
      localStorage.setItem('kpc_users', JSON.stringify(INITIAL_USERS));
    }
    if (!localStorage.getItem('kpc_employees')) localStorage.setItem('kpc_employees', JSON.stringify([]));
    if (!localStorage.getItem('kpc_notifications')) localStorage.setItem('kpc_notifications', JSON.stringify([]));
    if (!localStorage.getItem('kpc_invoices')) localStorage.setItem('kpc_invoices', JSON.stringify([]));
    if (!localStorage.getItem('kpc_payments')) localStorage.setItem('kpc_payments', JSON.stringify([]));
    if (!localStorage.getItem('kpc_financial_closing')) localStorage.setItem('kpc_financial_closing', JSON.stringify([]));
    if (!localStorage.getItem('kpc_financial_activity')) localStorage.setItem('kpc_financial_activity', JSON.stringify([]));
    if (!localStorage.getItem('kpc_clients')) localStorage.setItem('kpc_clients', JSON.stringify([]));
    if (!localStorage.getItem('kpc_executives')) localStorage.setItem('kpc_executives', JSON.stringify([]));
    if (!localStorage.getItem('kpc_ops_accounts')) localStorage.setItem('kpc_ops_accounts', JSON.stringify([]));
    if (!localStorage.getItem('kpc_accountant_accounts')) localStorage.setItem('kpc_accountant_accounts', JSON.stringify([]));
    if (!localStorage.getItem('kpc_session')) localStorage.setItem('kpc_session', JSON.stringify(null));
  },

  // Auth / Session Management
  login: (username, password) => {
    mockDb.init();
    
    // Check main users first (admin, ops)
    const users = JSON.parse(localStorage.getItem('kpc_users') || '[]');
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      const session = { role: user.role, userId: user.id, userName: user.name };
      localStorage.setItem('kpc_session', JSON.stringify(session));
      return session;
    }
    
    // HR Login (username = email, password = hr@123)
    const clients = mockDb.getClients();
    for (const client of clients) {
      const hr = (client.hrAccounts || []).find(h => h.email === username && h.status === 'Active');
      if (hr && password === 'hr@123') {
        const session = { role: 'hr', userId: hr.id, userName: hr.name, email: hr.email, company: client.name, clientId: client.id, hrRole: hr.role };
        localStorage.setItem('kpc_session', JSON.stringify(session));
        return session;
      }
    }
    
    // Exec Login (username = email, password = exec@123)
    const execs = mockDb.getExecutives();
    const exec = execs.find(e => e.email === username && e.status === 'Active');
    if (exec && password === 'exec@123') {
      const session = { role: 'exec', userId: exec.id, userName: exec.name, email: exec.email, designation: exec.designation };
      localStorage.setItem('kpc_session', JSON.stringify(session));
      return session;
    }

    return null; // Invalid credentials
  },

  getSession: () => {
    return JSON.parse(localStorage.getItem('kpc_session') || 'null');
  },

  logout: () => {
    localStorage.removeItem('kpc_session');
  },

  getCurrentUser: () => {
    return JSON.parse(localStorage.getItem('kpc_session'));
  },

  // Employee Operations
  getEmployees: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_employees') || '[]'); },
  saveEmployees: (employees) => { localStorage.setItem('kpc_employees', JSON.stringify(employees)); },
  getEmployeeById: (id) => { const employees = mockDb.getEmployees(); return employees.find(emp => emp.id === id); },
  addEmployee: (employee) => {
    const employees = mockDb.getEmployees();
    employees.unshift(employee);
    mockDb.saveEmployees(employees);
    mockDb.addNotification({
      type: employee.status === 'draft' ? 'draft' : 'upload',
      title: employee.status === 'draft' ? 'Draft Form Saved' : 'Document Uploaded & Submitted',
      message: employee.status === 'draft' ? `Draft form for ${employee.name} was saved.` : `Employee details and documents for ${employee.name} have been submitted.`,
      employeeId: employee.id,
      employeeName: employee.name
    });
    return employee;
  },
  updateEmployee: (id, updatedFields) => {
    const employees = mockDb.getEmployees();
    const index = employees.findIndex(emp => emp.id === id);
    if (index !== -1) {
      employees[index] = { ...employees[index], ...updatedFields };
      mockDb.saveEmployees(employees);
      return employees[index];
    }
    return null;
  },
  deleteEmployee: (id) => {
    const employees = mockDb.getEmployees();
    const filtered = employees.filter(emp => emp.id !== id);
    mockDb.saveEmployees(filtered);
  },

  // Notification Operations
  getNotifications: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_notifications') || '[]'); },
  saveNotifications: (notifications) => { localStorage.setItem('kpc_notifications', JSON.stringify(notifications)); },
  addNotification: (notification) => {
    const notifications = mockDb.getNotifications();
    const newNotif = { id: `notif-${Date.now()}`, timestamp: new Date().toISOString(), read: false, ...notification };
    notifications.unshift(newNotif);
    mockDb.saveNotifications(notifications);
    return newNotif;
  },
  markNotificationAsRead: (id) => {
    const notifications = mockDb.getNotifications();
    const updated = notifications.map(notif => notif.id === id ? { ...notif, read: true } : notif);
    mockDb.saveNotifications(updated);
  },
  markAllNotificationsAsRead: () => {
    const notifications = mockDb.getNotifications();
    const updated = notifications.map(notif => ({ ...notif, read: true }));
    mockDb.saveNotifications(updated);
  },

  // Invoice Operations
  getInvoices: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_invoices') || '[]'); },
  saveInvoices: (invoices) => { localStorage.setItem('kpc_invoices', JSON.stringify(invoices)); },
  addInvoice: (invoice) => {
    const invoices = mockDb.getInvoices();
    invoices.unshift(invoice);
    mockDb.saveInvoices(invoices);
    mockDb.addFinancialActivity({ event: 'Invoice Generated', desc: `${invoice.id} for ${invoice.clientName} auto-compiled & created`, type: 'invoice' });
    return invoice;
  },
  updateInvoice: (id, updatedFields) => {
    const invoices = mockDb.getInvoices();
    const index = invoices.findIndex(inv => inv.id === id);
    if (index !== -1) {
      invoices[index] = { ...invoices[index], ...updatedFields };
      mockDb.saveInvoices(invoices);
      return invoices[index];
    }
    return null;
  },

  // Payment Operations
  getPayments: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_payments') || '[]'); },
  savePayments: (payments) => { localStorage.setItem('kpc_payments', JSON.stringify(payments)); },
  addPayment: (payment) => {
    const payments = mockDb.getPayments();
    payments.unshift(payment);
    mockDb.savePayments(payments);
    mockDb.addFinancialActivity({ event: 'Payment Recorded', desc: `₹${payment.amount.toLocaleString('en-IN')} received from ${payment.clientName}`, type: 'payment' });
    return payment;
  },

  // Financial Closing Operations
  getFinancialClosing: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_financial_closing') || '{}'); },
  saveFinancialClosing: (closing) => { localStorage.setItem('kpc_financial_closing', JSON.stringify(closing)); },

  // Financial Activity Operations
  getFinancialActivity: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_financial_activity') || '[]'); },
  addFinancialActivity: (activity) => {
    const activities = mockDb.getFinancialActivity();
    const newAct = { id: `act-${Date.now()}`, date: new Date().toISOString(), ...activity };
    activities.unshift(newAct);
    localStorage.setItem('kpc_financial_activity', JSON.stringify(activities.slice(0, 50)));
    return newAct;
  },

  // Client Operations
  getClients: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_clients') || '[]'); },
  saveClients: (clients) => { localStorage.setItem('kpc_clients', JSON.stringify(clients)); },
  getClientById: (id) => { const clients = mockDb.getClients(); return clients.find(c => c.id === id); },
  addClient: (client) => {
    const clients = mockDb.getClients();
    clients.unshift(client);
    mockDb.saveClients(clients);
    return client;
  },
  updateClient: (id, updatedFields) => {
    const clients = mockDb.getClients();
    const index = clients.findIndex(c => c.id === id);
    if (index !== -1) {
      clients[index] = { ...clients[index], ...updatedFields };
      mockDb.saveClients(clients);
      return clients[index];
    }
    return null;
  },
  deleteClient: (id) => {
    const clients = mockDb.getClients();
    const filtered = clients.filter(c => c.id !== id);
    mockDb.saveClients(filtered);
  },
  getNextClientId: () => {
    const clients = mockDb.getClients();
    const maxSeq = clients.reduce((mx, c) => {
      const num = parseInt(c.id.replace('C-', ''), 10);
      return num > mx ? num : mx;
    }, 0);
    return `C-${String(maxSeq + 1).padStart(3, '0')}`;
  },

  // Executive Operations
  getExecutives: () => { mockDb.init(); return JSON.parse(localStorage.getItem('kpc_executives') || '[]'); },
  saveExecutives: (execs) => { localStorage.setItem('kpc_executives', JSON.stringify(execs)); },
  addExecutive: (exec) => {
    const execs = mockDb.getExecutives();
    execs.unshift(exec);
    mockDb.saveExecutives(execs);
    return exec;
  },
  updateExecutive: (id, fields) => {
    const execs = mockDb.getExecutives();
    const idx = execs.findIndex(e => e.id === id);
    if (idx !== -1) {
      execs[idx] = { ...execs[idx], ...fields };
      mockDb.saveExecutives(execs);
      return execs[idx];
    }
    return null;
  },
  getNextExecutiveId: () => {
    const execs = mockDb.getExecutives();
    const maxSeq = execs.reduce((mx, e) => {
      const num = parseInt(e.id.replace('EXEC-', ''), 10);
      return num > mx ? num : mx;
    }, 0);
    return `EXEC-${String(maxSeq + 1).padStart(3, '0')}`;
  }
};
